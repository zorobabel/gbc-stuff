/*
	GB Lemon tracker
 code by Lemon on 26 sept 99


 this exemple just launch the music player.
 you just need to add your code in this file et voila :)


 if you use this source (or part) in your code just put me in the credits... ^_^
 lemon@urbanet.ch

*/ 


#include <gb.h>

#include "sndplayer202f.c"

/****************************************************************************/

void main()
{

clock=0;
step=0;
patern=0;
stopmusic();
patern_definition();

while (1)
{
	if (clock>=7){clock=0;}      // set the speed of your music

	wait_vbl_done();

	if (!clock) {music();}

	clock+=1;

	}
}
