This is an early source code for my Gameboy game Pocket Panic, which I recently
won second prize for in Bungs game coding compo (www.bung.com.hk).. This source
was taken from about 20 days after I re-started the project from scratch, as the
earliest version was bugged to fuck. This version has its bugs too, it's not
brilliant, but I decided it wouldn't do any harm releasing this source into the
public domain. The only thing I ask is that you *learn* from my source code, and
not *rip* any large chunks from it.

13/7/99 stevej@dominionamtx.freeserve.co.uk