// Full Screen Image Example for Original Game Boy (GBDK)
// by Molasses
// molasses@ihug.com.au
// 3 May 2000

// ---- NOTE
//      You only need to use this method on Original Game Boy for displaying a full screen image with more
//      than 256 unique background tiles. If your image is only for Game Boy Color then you can just use the
//      2nd background bank to store more than 256 unique background tiles.

// ---- HOW THIS WORKS
//      Firstly, the original Game Boy does have space for more than 256 background tiles.
//      It in fact has space for 384 background tiles.
//
//      It's background tiles are normally stored at address :
//      0x8000 - 0x8FFF  Here the tiles are numbered 0 to 255
//
//      But background tiles can also be stored at address :
//      0x8800 - 0x97FF  Here the tiles are numbered -128 to 127
//
//      As you can see, these memory address's overlap :
//
//       0x8000 --------------- 0x8FFF
//      Tiles 0 --------------- 255
//                 0x8800 ------------------ 0x97FF
//             Tiles -128 ------------------ 127
//
//      Therefore, we can load 240 tiles (12 rows, with each row being 20 tiles wide) into the first section
//      and 120 tiles into the second section. Thus giving us a total of 360 unique background tiles (a full
//      20x18 tile screen!) :
//
//       0x8000 --------------- 0x8F00
//      Tiles 0 --------------- 239
//                              0x9000 ------------ 0x9780
//                             Tiles 0 ------------ 119
//
//      Of course once we load all of our background tiles into these 2 sections, they don't all show up at once.
//      We need to switch which section of memory background data is being read from, and we need to do it while
//      the screen is still being drawn.
//
//      Bit 4 of the LCDC_REG tells the Game Boy which section of memory we want to use for the background data.
//
//              Bit 4 - BG & Window Tile Data Select
//                      0: 0x8800-0x97FF
//                      1: 0x8000-0x8FFF <- Same area as OBJ
//
//      As this is either set to the first section or the second section, we will have to switch this bit after
//      the first 12 rows of the background are drawn.
//
//      We will set the LCD interrupt to do this for us. We want this interrupt to occur after the twelth row of
//      the background has been drawn. The LY_REG holds the number of the current horizontal line being drawn and
//      the number in the LYC_REG can be compared against the LY_REG to trigger the LCD interrupt when their values
//      are equal.
//
//      So, we should set LYC_REG = 96 (the line number after 12 rows * 8 pixels = 96 pixels).
//      However, I find that the interrupt is triggered one line after, so I set LYC = 95.
//      We also set bit 6 of STAT_REG on, which selects the LY==LYC comparison to trigger the LCD interrupt.
//
//      Once the LCD interrupt occurs, we switch bit 4 of LCDC_REG off. Then the background tile data is read
//      from the second section for the last 6 rows.
//      Then at the end of the VBlank we have a VBL interrupt set to switch bit 4 of LCDC_REG back on.
//      Otherwise background tile data would be read from the second section when the screen redraws.
//
//      So these 2 interrupts keep going every time the screen redraws (each VBlank) and everything is happy.
//
//      Simple enough, really. :)
//
//      (Make sure you look at title.c to see how the background is stored and how the tile map is set)

#include <gb.h>
#include "title.c"                        // background data and map : look at how it's stored

void LCD()
{
LCDC_REG &= 0xEF;                         // switch bit 4 off : 0x8800-0x97FF
}

void VBL()
{
LCDC_REG |= 0x10;                         // switch bit 4 on : 0x8000-0x8FFF
}

void main()
{
set_data((void*)0x8000, bkgdata1, 0xF00); // load the first 240 tiles to 0x8000-0x8F00
set_data((void*)0x9000, bkgdata2, 0x780); // load the remaining 120 tiles to 0x9000-0x9780

set_bkg_tiles(0, 0, 20, 18, tilemap);     // set the background tile map

disable_interrupts();                     // turn interrupts off before messing with them
add_LCD(LCD);                             // add the function LCD to the LCD interrupt
add_VBL(VBL);                             // add the function VBL to the VBL interrupt
set_interrupts(VBL_IFLAG | LCD_IFLAG);    // set the VBL and LCD interrupts on
LYC_REG = 95;                             // this will trigger the LCD interrupt after the 95th row is drawn
STAT_REG |= 0x40;                         // switch bit 6 on : selects LY==LYC comparison to trigger the LCD interrupt
enable_interrupts();                      // turn the interrupts back on

SHOW_BKG;                                 // show the background layer
}
