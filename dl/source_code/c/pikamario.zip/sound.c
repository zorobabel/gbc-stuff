unsigned long muspos, mustim, musrepeatpos;

void sndInit()
{
  *(UBYTE*)0xFF26 = 1<<7;                   // all sound on
  *(UBYTE*)0xFF26 =  1<<7 | 1 | 2 | 4 | 8;  // sounds 1-4 on
  *(UBYTE*)0xFF25 = 0xFF;                   // ouput all sounds
  *(UBYTE*)0xFF24 = 7<<4 | 7;               // volume for SO1 & SO2
}

void sndThump()
{
  *(UBYTE*)0xFF20 =  63;                // length(0-63)
  *(UBYTE*)0xFF21 = 15<<4 | 0<<3 | 1; 	// envelope: initial volume(0-15), down/up(0-1), number of sweeps(0-7)
  *(UBYTE*)0xFF22 = 13<<4 | 0<<3 | 5; 	// polynomial frequency(0-13), counter step(0-1:15/7), divide ratio(0-7)
  *(UBYTE*)0xFF23 = 1<<7 | 0<<6;        // initial(0-1), consecutive(0-1)
}

void sndQuake()
{
  *(UBYTE*)0xFF20 =  63;                // length(0-63)
  *(UBYTE*)0xFF21 = 15<<4 | 0<<3 | 7; 	// envelope: initial volume(0-15), down/up(0-1), number of sweeps(0-7)
  *(UBYTE*)0xFF22 = 13<<4 | 0<<3 | 5; 	// polynomial frequency(0-13), counter step(0-1:15/7), divide ratio(0-7)
  *(UBYTE*)0xFF23 = 1<<7 | 0<<6;        // initial(0-1), consecutive(0-1)
}

void sndJump()
{
  *(UBYTE*)0xFF16 = 0<<6 | 63;          // wave pattern duty / sound length
  *(UBYTE*)0xFF17 = 7<<4 | 0<<3 | 1; 	// volume / envelope
  *(UBYTE*)0xFF18 = 0 & 0xFF;           // frequency
  *(UBYTE*)0xFF19 = 128 | 0/256;        // initial flag / frequency
}

enum notes {
  C0, Cd0, D0, Dd0, E0, F0, Fd0, G0, Gd0, A0, Ad0, B0,
  C1, Cd1, D1, Dd1, E1, F1, Fd1, G1, Gd1, A1, Ad1, B1,
  C2, Cd2, D2, Dd2, E2, F2, Fd2, G2, Gd2, A2, Ad2, B2,
  C3, Cd3, D3, Dd3, E3, F3, Fd3, G3, Gd3, A3, Ad3, B3,
  C4, Cd4, D4, Dd4, E4, F4, Fd4, G4, Gd4, A4, Ad4, B4,
  C5, Cd5, D5, Dd5, E5, F5, Fd5, G5, Gd5, A5, Ad5, B5,
  none, END
};

UWORD frequencies[] = {
  44, 156, 262, 363, 457, 547, 631, 710, 786, 854, 923, 986,
  1046, 1102, 1155, 1205, 1253, 1297, 1339, 1379, 1417, 1452, 1486, 1517,
  1546, 1575, 1602, 1627, 1650, 1673, 1694, 1714, 1732, 1750, 1767, 1783,
  1798, 1812, 1825, 1837, 1849, 1860, 1871, 1881, 1890, 1899, 1907, 1915,
  1923, 1930, 1936, 1943, 1949, 1954, 1959, 1964, 1969, 1974, 1978, 1982,
  1985, 1988, 1992, 1995, 1998, 2001, 2004, 2006, 2009, 2011, 2013, 2015
};

UBYTE music1[] = {
			 //------CLOONEY TUNE-------\\
			//---By my Biggest Brother---\\
			//-----SONG LENGTH = 127-----\\
	none,
	  C3,none,  G3,none,  F3,none,  E3,  D3,  C3,none,  E3,none,  G3,
	none,none,none,  F3,none,none,  G3,  A3,  G3,  F3,  E3,  D3,none,
	none,none,none,none,  C3,  B2,  C3,none,  G3,none,  F3,none,  E3,
	  D3,  C3,none,  E3,none,  G3,none,none,none,  C4,  C4,none,  C4,
	  B3,none,  C4,none,  D4,none,  C4,  B3,  C4,none,none,none,none,
	  E4,  E4,  E4,  E4,  E4,  E4,  F4,  G4,  A4,none,  G4,  F4,  G4,
	none,  E4,  D4,  C4,  C4,  C4,  C4,  C4,  C4,  D4,  E4,  F4,none,
	  E4,  D4,  E4,none,  C4,  B3,  A3,  A3,  A3,  A3,  A3,  A3,  B3,
	  C4,  D4,none,  C4,  B3,  C4,none,none,none,  G3,none,none,  B3,
	  C4,  C4,  B3,  A3,  C4,none,  E4,  G4,  C5,none,none,none,none,
	none,none,none,none,none, END
};


void PlayMusic()
{
 if(mustim=0xFF)
 {
  if(music1[muspos] != END) {
    if(music1[muspos] != none) {
      *(UBYTE*)0xFF12 = 9<<2 | 0<<6 | 6;
      *(UBYTE*)0xFF13 = frequencies[music1[muspos]] & 0xFF; // frequency
      *(UBYTE*)0xFF14 = 128 | frequencies[music1[muspos]]>>8; // initial flag / frequency

    }
    muspos++;
    if(music1[muspos] == END) {
      muspos=musrepeatpos;
//      *(UBYTE*)0xFF12 = 0<<4 | 1<<3 | 0;
      return;
    }
  }
  mustim=0;
 } else { mustim++; }
}

void StopMusic()
{
  *(UBYTE*)0xFF12 = 0<<4 | 1<<3 | 0;
}
