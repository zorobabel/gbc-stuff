#include <gb.h>
#include "sprites.c"
#include "sprites.h"
#include "win.c"
#include "title_m.c"
#include "title_t.c"
#include "title_t.h"
#include "gameover.c"
#include "map.c"
#include "tiles.c"
#include "tiles.h"
#include "sound.c"
#include "scroll.c"	// <--- JOTTED's SCROLLING ROUTINES!

#define lowestmy 112

void Die();
void Jump();
void smooth_it();
void InitGame();

UWORD palSprit[] = { 
  spritesCGBPal0c0,spritesCGBPal0c1,spritesCGBPal0c2,spritesCGBPal0c3,
  spritesCGBPal1c0,spritesCGBPal1c1,spritesCGBPal1c2,spritesCGBPal1c3,
  spritesCGBPal2c0,spritesCGBPal2c1,spritesCGBPal2c2,spritesCGBPal2c3,
  spritesCGBPal3c0,spritesCGBPal3c1,spritesCGBPal3c2,spritesCGBPal3c3,
  spritesCGBPal4c0,spritesCGBPal4c1,spritesCGBPal4c2,spritesCGBPal4c3,
  spritesCGBPal5c0,spritesCGBPal5c1,spritesCGBPal5c2,spritesCGBPal5c3,
  spritesCGBPal6c0,spritesCGBPal6c1,spritesCGBPal6c2,spritesCGBPal6c3,
  spritesCGBPal7c0,spritesCGBPal7c1,spritesCGBPal7c2,spritesCGBPal7c3
};
UWORD palBack[] = {
  tilesCGBPal0c0,tilesCGBPal0c1,tilesCGBPal0c2,tilesCGBPal0c3,
  tilesCGBPal1c0,tilesCGBPal1c1,tilesCGBPal1c2,tilesCGBPal1c3,
  tilesCGBPal2c0,tilesCGBPal2c1,tilesCGBPal2c2,tilesCGBPal2c3,
  tilesCGBPal3c0,tilesCGBPal3c1,tilesCGBPal3c2,tilesCGBPal3c3,
  tilesCGBPal4c0,tilesCGBPal4c1,tilesCGBPal4c2,tilesCGBPal4c3,
  tilesCGBPal5c0,tilesCGBPal5c1,tilesCGBPal5c2,tilesCGBPal5c3,
  tilesCGBPal6c0,tilesCGBPal6c1,tilesCGBPal6c2,tilesCGBPal6c3,
  tilesCGBPal7c0,tilesCGBPal7c1,tilesCGBPal7c2,tilesCGBPal7c3
};

unsigned long mx, my, mariojumping,jumppos, btn,sx, pts, lives;
unsigned stepcount, speed,mapx,mapy, yourcolor, pose;
//			   ^     ^		  ^
//			column  row             guess

signed int jumptable[]={3,3,3,3,3,3,3,2,2,2,2,
                        2,2,2,2,1,1,1,1,1,1,1,0,0,0,0,
                        0,0,0,0,1,1,1,1,1,1,1,2,2,2,2,
                        2,2,2,2,3,3,3,3,3,3,3};

/* THESE TWO FROM DEEPSCAN EXAMPLE */
void ShowScore( UWORD s )
{
  UWORD m;
  UBYTE i, n, f;
  unsigned char score[3];

  f = 0; m = 10000;
  for( i=0; i<4; i++ ) {
    n = s/m; s = s%m; m = m/10;
    if( (n==0)&&(f==0) ) {
      score[i] = 0x20;      /* ' ' */
    } else {
      f = 1;
      score[i] = 0x30+n;    /* '0' - '9' */
    }
  }
  score[3] = 0x30;      /* '0' */
  VBK_REG=0; set_win_tiles( 16 , 0, 1, 3, score );
}
void ShowLives( UBYTE i )
{
  unsigned char level[2];
  i--;
  if( i < 9 ) {
    level[0] = 0x31+i;
  } else {
    level[0] = 0x41+i-9;
  }
  VBK_REG=0; set_win_tiles( 1, 0, 1, 1, level );
}

/* END OF RIPS */

void scroll()    //Another one by Jotted to initiate scolling
{
    if(direction == 0)
    {
         if(zero_to_eight == 8)
         {  
              x++;
              if(x > (map_x - 1)) x = 0;
              cnt++;
              if(cnt == 32) cnt = 0;
              chunk_it(0, 18, x, mapPLN0, mapPLN1);
              copy_it(cnt, 1);
              zero_to_eight = 0;            
         }         
    }
    // If going left...
    if(direction == 1)
    {
         if(zero_to_eight == 0)
         {
              x--;
              if(x > (map_x - 1)) x = 79;
              cnt--;
              if(cnt > 31) cnt = 31;
              chunk_it(0, 18, x, mapPLN0, mapPLN1);
              copy_it(cnt, 1);
              zero_to_eight = 8;              
         }
    }
} 

void PlayGame()
{
  int temp;
  while(1)
  {
    ShowScore(pts);
    ShowLives(lives);
    Jump();
    if (my > lowestmy ) { jumppos=0; mariojumping=0;	
		my=lowestmy; pose=0; }
    move_sprite(0,64,my);
    set_sprite_tile(0,pose+(zero_to_eight/2));
    btn=joypad();
    if(btn & J_B) { sndJump(); mariojumping=1; }
    if(btn & J_LEFT) { set_sprite_prop(0,S_FLIPX); sx--; mx--; zero_to_eight--; if(direction == 0) {x -= 20; cnt -= 20;} direction = 1;}
    if(btn & J_RIGHT) { set_sprite_prop(0,0); sx++; mx++; zero_to_eight++;  if(direction == 1){x += 20; cnt += 20;} direction = 0;}
    if(btn & J_DOWN) { set_sprite_tile(0,14); }
    if(btn & J_SELECT) { Die(); }
    
    mapx=mx/8;
    mapy=(my/8)-2;

    scroll();
    delay(speed);
  }
}

void Die()
{
  long a;
  set_sprite_tile(0,6);
  set_sprite_prop(0,0);
  for(a=my; a > 16; a-=4)
  {
    move_sprite(0,64,a);
    delay(40);
  }
  set_sprite_tile(0,8);
  for(a=16; a < lowestmy+2; a+=4)
  {
    move_sprite(0,64,a);
    delay(40);
  }
  sndQuake();
  waitpad(J_B | J_A | J_START | J_SELECT);
  lives--;
  if(lives== 0 )
  {
    disable_interrupts();
    VBK_REG=1; set_bkg_tiles(0,0,20,18,GameoverPLN1);
    VBK_REG=2; set_bkg_tiles(0,0,20,18,GameoverPLN0);
    move_bkg(0,0);
    move_win(7,200);
    move_sprite(0,0,0);
    waitpad(J_START); InitGame();
  }
}

void Jump()
{
  if (mariojumping == 0) return;
  if (jumppos < 26 ) { pose=4; my -= jumptable[jumppos]; }
  if (jumppos > 26 ) { pose=8; my += jumptable[jumppos]; }
  if (jumppos != 53) { jumppos++; }
}

void smooth_it()     // A function added by Jotted for smoother scrolling
{
      SCX_REG = sx;             
}                       

void main()
{
  // Jotted's little family of VERY important variables
  map_x = 200;                // Width of map must be known to make scrolling right
  x = 0;                           // This marks the X axis of where the next map column is.
  zero_to_eight = 0;         // DUH!  When it reaches 8, the scrolling functions get to work!
  cnt = 20;  
  direction = 0;                // 0 for right, 1 for left 
  
  DISPLAY_OFF;
  sndInit();
  set_bkg_palette(0,40,&palBack[0]);
  set_bkg_data(0,255,tiles);
  set_win_data(0,255,tiles);
  VBK_REG=1; set_bkg_tiles(0,0,20,18,TitleMapPLN1);
  VBK_REG=0; set_bkg_tiles(0,0,20,18,TitleMapPLN0);
  DISPLAY_ON;
  SHOW_BKG;

  while(1) { btn=joypad(); if(btn & J_START) { break; } }
  InitGame();
}

void InitGame()
{
  disable_interrupts();
  add_TIM(PlayMusic);
  add_VBL(smooth_it);  //This is the line you were missing, it's very very important   -Jotted
  enable_interrupts();
  TMA_REG = 0x00U;
  TAC_REG = 0x04U;
  set_interrupts(VBL_IFLAG | TIM_IFLAG);

  DISPLAY_OFF;
  set_sprite_data(0,100,sprites);
  set_sprite_palette( 0, 2, &palSprit[0]);
  
  chunk_it(0, 18, x, mapPLN0, mapPLN1);  
  copy_it(0, 32);   
  x=20;
  VBK_REG=1; set_win_tiles(0,0,20,2,winPLN1);
  VBK_REG=0; set_win_tiles(0,0,20,2,winPLN0);
  move_win(7,136);
  SHOW_WIN;
  SPRITES_8x16;
  set_sprite_tile(0,0);
  SHOW_SPRITES;
  SHOW_BKG;
  DISPLAY_ON;
  
  mx=60;my=lowestmy; StopMusic(); pts=999;
  speed=20;lives=3; set_sprite_tile(2,10); set_sprite_prop(0,0);
  musrepeatpos=0;
  PlayGame();
}  
	