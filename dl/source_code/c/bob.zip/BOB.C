/*
Bob The Plumber
Written by Jason
*/

#include <gb.h>
#include <colors.h>

void loadtiles1();
void loadbg();
void vblint();
void renderrow(unsigned int x, unsigned int metanum);
void renderlevel();
void updatelevel();
void loadinfo1();

unsigned int doshit;
unsigned int level;
unsigned int scrollnum;
unsigned int tilenum;
unsigned int scrollcnt;
unsigned int pixelmoved;
unsigned int coins;

UWORD spritepalette[] ={
black,black,black,black,
white,brown,yellow,black,
black,darkgray,lightgray,white,
};

UWORD backgroundpalette[] = {
blue,green,black,white,
blue,green,black,white,
blue,orange,darkred,black
};

UWORD backgroundpalette2[] = {
blue,green,black,white,
black,green,darkgreen,white,
black,blue,darkblue,black
};
UWORD backgroundpalette3[] = {
darkblue,green,black,white,
darkblue,darkgreen,black,lightgray,
darkblue,orange,darkred,black
};

unsigned char colormap[] = {
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
};
unsigned char zero[] = {
0,0,0,0
};

unsigned char burp[] = {
0,1,2,3,4,5,6,7,8,9,10,
11,12,13,14,15,16,17,18,19,20,
21,22,23,24,25,26,27,28,29,30,
31,32,33,34
};

unsigned char level1[] = {
20,20,20,20,25,30,25,26,29,30,20,20,25,30,20,20,22,23,20,20,
20,20,21,21,22,23,21,21,22,23,21,21,20,20,20,20, 0, 0,20,20,
25,30, 0, 0, 0, 0,20,20,20,20, 0, 0, 0, 0,20,20,20,20,25,30,
25,30, 0, 0,20,20,20,20,21,21,20,20,21,21,22,23,21,21,24,24,
24,24, 0, 0,20,20,20,20, 0, 0,25,26,29,30,21,21,20,20, 0, 0,
20,25,30,20,22,23,20,20,22,23,20,20,22,23,20,20,20,20,24,24,
24,24,20,20,24,24, 0, 0,24,24,20,20,21,21,24,24, 0, 0,25,30,
21,21,21,21,22,23,21,21,20,20, 0, 0, 0, 0,20,20,20,20,31,32,
20,20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

unsigned char level2[] = {
20,20,20,20,20,20,20,20,22,23,22,23,22,23,20,20,21,21, 0, 0,
21,21,21,21, 0, 0,21,21,20,20,20,20,20,20,21,21,22,23,21,21,
 0, 0,21,21,22,23,21,21,20,20,20,20,20,20,21,21,24,24,24,24,
 0, 0,20,20,21,21, 0, 0, 0, 0,20,20,20,20,20,20, 0, 0, 0, 0,
20,20,20,20,20,20, 0, 0, 0, 0,20,20,20,20,20,20, 0, 0, 0, 0,
20,20,20,20, 0, 0,21,21,21,21, 0, 0, 0, 0,20,20,20,20,20,20,
21,21,24,24,24,24, 0, 0, 0, 0,24,24,22,23,24,24, 0, 0, 0, 0,
21,21,21,21,22,23,22,23,20,20,31,32,20,20, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

unsigned char level3[] = {
20,20,25,30,25,26,29,30,20,20,20,20,20,20, 0, 0, 0, 0,33,34,
34,34,34,35, 0, 0, 0, 0,20,20,25,30, 0, 0,24,24,24,24,24,24,
24,24,20,20, 0, 0, 0, 0,20,20,24,24,33,34,35, 0,20,20,21,21,
24,24,22,23, 0, 0, 0, 0,20,20,21,21,22,23,21,21,24,24, 0, 0,
 0, 0, 0, 0,20,20,22,23,20,20, 0, 0,20,20,33,34,34,35,24,24,
 0, 0,24,24,24,24, 0, 0,24,24, 0, 0,24,24, 0, 0, 0, 0,20,20,
33,34,34,35, 0, 0,24,24,20,20,20,20,24,24, 0, 0,24,24,22,23,
20,20,20,20,20,20,24,24,22,23,24,24,21,21,22,23,21,21,20,20,
20,20,20,20,31,32,20,20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 
};

/*
unsigned char level2[] = {
1,1,1,1,6,7,10,11,1,1,0,0,1,1,2,2,5,5,2,2,
3,4,1,1,0,0,1,1,1,1,0,0,0,1,6,11,1,1,0,0,
1,1,5,5,0,0,5,5,1,1,5,5,0,0,1,1,0,0,5,5,
0,0,14,15,15,16,0,0,0,0,1,6,7,8,9,10,11,1,0,0,
1,1,1,1,0,0,1,1,0,0,1,1,1,1,0,0,0,1,1,1,
0,0,14,15,15,16,1,0,1,1,0,1,1,0,0,0,1,1,
0,0,14,16,1,1,0,0,1,1,0,0,6,11,6,7,10,11,0,0,
1,1,2,2,5,5,2,2,1,1,0,0,1,1,1,2,2,2,0,0,
5,5,5,1,1,1,0,0,1,1,1,1,6,7,10,11,3,4,6,11,
12,13,6,11,1,1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

unsigned char level1[] = {
1,1,6,7,8,9,10,11,1,1,1,1,6,11,6,11,2,2,1,1,
1,1,1,1,2,2,3,4,2,2,2,2,14,15,15,16,6,7,8,9,
10,11,0,0,0,0,0,0,1,1,1,1,6,11,6,11,0,0,0,0,
5,5,3,4,5,5,0,0,0,0,5,5,5,5,5,5,0,0,0,0,
6,11,6,7,8,9,10,11,5,5,1,1,1,1,1,1,5,5,5,5,
5,5,1,1,3,4,1,1,5,5,6,11,5,5,1,1,5,5,5,5,
1,1,1,1,5,5,5,5,5,5,0,0,0,0,0,0,5,5,1,1,
0,0,1,1,1,1,0,0,0,0,1,1,1,1,45,46,46,46,46,47,
6,7,10,11,1,1,6,7,8,9,10,11,5,5,5,5,3,4,5,5,
1,1,0,0,0,0,0,0,1,1,14,15,15,16,0,0,1,1,0,0,
1,1,1,1,12,13,1,1,0,0,0,0,0,0,0,0,0,0,0,0,
};

unsigned char level3[] = {
1,1,6,11,6,7,10,11,1,1,0,0,0,0,1,1,1,1,0,0,
1,1,3,4,2,2,1,1,1,1,0,0,0,0,1,1,1,1,0,0,
0,0,1,1,0,0,1,1,0,0,0,0,1,1,1,1,0,0,1,1,
14,15,15,15,18,18,18,19,1,1,1,1,1,1,0,0,0,0,1,1,
5,5,0,0,0,0,0,0,5,5,1,1,1,1,0,0,1,1,1,1,
2,2,5,5,2,2,3,4,2,2,5,5,5,5,0,0,1,1,1,1,
0,0,5,5,1,1,0,0,1,1,5,5,1,1,0,0,0,0,0,0,
1,1,1,1,0,0,0,0,1,5,5,1,0,0,0,0,1,1,5,5,
0,0,0,0,5,5,1,1,17,18,18,19,6,11,6,11,0,0,0,0,
1,1,0,0,1,1,0,0,1,1,1,1,0,0,0,0,1,1,1,1,
5,5,0,0,0,0,0,0,1,1,1,1,1,1,0,0,5,5,1,1,
1,1,3,4,12,13,3,4,1,0,0,0,0,0,0,0,0,0,0,0,
};
*/

unsigned char level4[] = {
1,1,1,1,1,6,11,1,1,1,0,0,17,18,15,15,15,16,1,1,
0,0,1,1,5,5,0,0,0,0,5,5,0,0,0,0,0,0,1,1,
1,1,0,0,1,0,1,1,0,1,0,0,1,1,0,0,0,0,1,1,
5,5,0,0,0,5,1,0,0,0,1,1,17,18,15,15,18,18,15,16,
0,0,1,5,0,0,0,0,5,5,1,1,0,0,0,0,1,1,1,1,
0,0,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,
0,0,5,5,14,15,15,16,6,11,0,0,0,1,5,5,0,0,
3,4,2,5,1,1,0,0,1,1,0,0,0,0,1,1,5,5,0,0,
0,0,0,0,1,1,1,1,48,49,48,50,48,49,48,1,0,0,0,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

unsigned char level5[] = {
1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,1,5,5,0,0,
0,0,0,1,1,1,2,2,0,0,0,0,5,5,0,0,1,1,2,2,
0,0,3,4,3,4,5,5,0,0,5,5,2,2,0,0,1,1,0,0,
5,5,2,2,1,1,0,0,0,0,0,0,2,2,0,0,1,1,0,0,
0,0,0,1,1,0,0,0,2,2,1,1,1,1,1,1,1,1,1,1,
1,1,3,4,3,4,1,1,1,1,0,0,0,0,1,1,5,5,0,0,
0,0,0,1,1,1,2,2,0,0,0,0,5,5,0,0,1,1,2,2,
0,0,3,4,3,4,5,5,0,0,5,5,2,2,0,0,1,1,0,0,
5,5,2,2,1,1,0,0,0,0,0,0,2,2,0,0,1,1,0,0,
0,0,0,1,1,0,0,0,2,2,1,1,12,13,1,1,
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

unsigned char level6[] = {
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
};

unsigned char level7[] = {
20,20,25,26,27,28,29,30,33,34,34,34,34,35,20,20,20,20,0,0,
0,0,0,0,0,0,20,20,0,0,0,0,0,0,0,0,20,20,0,0,
0,0,0,0,0,0,20,20,0,0,0,0,0,24,24,24,24,24,0,0,
0,0,0,0,0,0,24,24,0,0,0,0,0,0,0,0,20,20,0,0,
0,0,0,0,0,0,20,20,0,0,0,0,0,24,24,24,24,24,0,0,
0,0,0,0,0,0,21,21,0,0,0,0,0,0,20,20,24,24,22,23,
24,24,20,20,0,0,0,0,0,0,20,20,0,0,0,0,0,0,20,20,
0,0,0,0,0,0,20,0,20,0,20,0,0,0,20,20,0,0,20,20,
24,24,24,24,20,20,0,0,0,0,20,20,0,0,20,20,0,0,20,20,
0,0,0,0,0,24,24,24,0,0,0,0,0,0,0,0,20,20,0,0,
20,20,20,20,20,20,20,20,20,20,0,0,0,0,0,0,0,0,0,20,
20,31,32,20,20,0,0,0,0,0,0,0,0,0,
};

unsigned char level100[] = {
38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,
38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,
38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,
38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,
38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,38,39,
36,36,36,36,41,42,36,36
};

unsigned char misc[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
24,24,60,60,126,126,255,255,255,255,126,126,60,60,24,24,
};

UWORD gpalette[] = {
black,black,black,black,
darkgray,darkgray,darkgray,darkgray,
};

main()
{
  unsigned int bobx, boby, temp, temp2, playing, lives;
  int standing, jumpheight, jumpable, direction;
  unsigned char tilenum;
 
  delay(100);
  if(joypad() == J_SELECT) {
    SHOW_BKG;
    set_sprite_data(0,4,misc);
    set_sprite_tile(0,1);
    set_sprite_tile(1,1);
    set_sprite_tile(2,1);
    set_sprite_tile(3,1);
    set_sprite_tile(4,1);
    set_sprite_tile(5,1);
    set_sprite_tile(6,1);
    set_sprite_tile(7,1);
    set_sprite_tile(8,2);
    set_sprite_palette(0,2,&gpalette[0]);
    set_sprite_prop(0,0);
    set_sprite_prop(1,0);
    set_sprite_prop(2,0);
    set_sprite_prop(3,0);
    set_sprite_prop(4,0);
    set_sprite_prop(5,0);
    set_sprite_prop(6,0);
    set_sprite_prop(7,0);
    set_sprite_prop(8,0); 
    SPRITES_8x8;
    SHOW_SPRITES;
    SWITCH_ROM_MBC1(2);
    loadinfo1();
  }

  disable_interrupts();
  add_vbl(vblint);
  doshit = 0;
  scrollnum = 0;
  tilenum = 0;
  scrollcnt = 0;
  playing = 1;
  level = 0;
  coins = 0;

  // Color shit
  DISPLAY_OFF;
  if(_cpu == 0x11) { 				// if cpu is a gameboy color
    set_sprite_palette(0,6,&spritepalette[0]);
    set_sprite_prop(0,spritepalette[1]);
    set_sprite_prop(1,spritepalette[1]);
    set_sprite_prop(2,spritepalette[1]);
    set_sprite_prop(3,spritepalette[1]);
    set_sprite_prop(4,spritepalette[1]);
    set_sprite_prop(5,spritepalette[1]);   
    set_sprite_prop(30,1);   
    set_sprite_prop(31,1);   
    set_sprite_prop(32,1);   
    set_sprite_prop(33,1);
    set_sprite_prop(34,1);   
    set_sprite_prop(35,1);   
    set_sprite_prop(36,1);   
    set_sprite_prop(37,1);   
    set_sprite_prop(38,1);   
    set_sprite_prop(39,1);   
    set_bkg_palette( 0, 3, &backgroundpalette[0] );
    VBK_REG = 1;
    set_bkg_tiles(0,16,32,1,colormap);
    set_bkg_tiles(0,17,32,1,colormap);
    set_bkg_tiles(0,8,32,1,colormap);
    set_bkg_tiles(0,9,32,1,colormap);
    VBK_REG = 0;
  }
  DISPLAY_ON;
  enable_interrupts();

  // initial values   
  bobx = 64;
  boby = 120;
  standing = 1;
  jumpheight = 0;
  jumpable = 0;
  lives = 3;
  SPRITES_8x8;

  SWITCH_ROM_MBC1(2);
  loadtiles1();
  loadbg();
  SWITCH_ROM_MBC1(3);
	
  renderlevel();

  // for burp
  set_bkg_tiles(5,5,5,7,burp);

  set_sprite_tile(0,1);
  set_sprite_tile(1,2);
  set_sprite_tile(2,3);
  set_sprite_tile(3,4);
  set_sprite_tile(4,7);
  set_sprite_tile(5,8);
  move_sprite(0,50,50);
  move_sprite(1,58,50);
  move_sprite(2,50,58);
  move_sprite(3,58,58);
  move_sprite(4,50,66);
  move_sprite(5,58,66);

  set_sprite_tile(25,13);
  set_sprite_tile(26,14);
  set_sprite_tile(27,15);
  set_sprite_tile(28,16);
//  move_sprite(25,100,20);
//  move_sprite(26,108,20);
//  move_sprite(27,100,28);
//  move_sprite(28,108,28);

  set_sprite_tile(39,36);
  set_sprite_tile(38,37);
  set_sprite_tile(37,36);
  move_sprite(39,16,24);
  move_sprite(38,24,24);
  move_sprite(37,32,24);

  set_sprite_tile(36,50);
  set_sprite_tile(35,39);
  move_sprite(36,80,24);
  move_sprite(35,88,24);

  set_sprite_tile(34,38);
  set_sprite_tile(33,42);
  move_sprite(34,48,24);
  move_sprite(33,56,24);

  set_sprite_tile(32,38);
  set_sprite_tile(31,40);
  set_sprite_tile(30,40);
  move_sprite(32,148,24);
  move_sprite(31,140,24);
  move_sprite(30,156,24);
  SHOW_SPRITES;
  SHOW_BKG;
  
  while(playing == 1)
  {
    if((boby > 200) && (boby < 205)) {
	lives--;
	if(lives != 0) {
	  if(lives == 9) set_sprite_tile(33,48);
	  if(lives == 8) set_sprite_tile(33,47);
	  if(lives == 7) set_sprite_tile(33,46);
	  if(lives == 6) set_sprite_tile(33,45);
	  if(lives == 5) set_sprite_tile(33,44);
	  if(lives == 4) set_sprite_tile(33,43);
	  if(lives == 3) set_sprite_tile(33,42);
	  if(lives == 2) set_sprite_tile(33,41);
	  if(lives == 1) set_sprite_tile(33,40);
          bobx = 64;
          boby = 120;
          standing = 1;
          jumpheight = 0;
          jumpable = 0;
          doshit = 0;
          scrollnum = 0;
          tilenum = 0;
          scrollcnt = 0;
	  move_bkg(0,0);
	  pixelmoved = 0;
	  if(direction == 1) {
            move_sprite(0,bobx,boby);
            move_sprite(1,bobx+8,boby);
            move_sprite(2,bobx,boby+8);
            move_sprite(3,bobx+8,boby+8);
            move_sprite(4,bobx,boby+16);
            move_sprite(5,bobx+8,boby+16);		
	  }
	  if(direction == 2) {
            move_sprite(0,bobx+8,boby);
            move_sprite(1,bobx,boby);
            move_sprite(2,bobx+8,boby+8);
            move_sprite(3,bobx,boby+8);
            move_sprite(4,bobx+8,boby+16);
            move_sprite(5,bobx,boby+16);
	  }
          renderlevel();
	}
	if(lives == 0) {
		reset();
	}
    }  
    // jump control
    if(joypad() & J_A) {
      if(jumpable == 0) {
        jumpheight = 0;
        jumpable = 1;
      }
    }
    if(jumpable == 2) {
      // check routines
      temp2 = (pixelmoved / 8) + (bobx / 8);
      if(temp2 > 31) temp2 = temp2 - 32;
      get_bkg_tiles(temp2,boby / 8 + 1,1,1,&tilenum);
      if((tilenum == 0x00) || (tilenum == 0x18) || (tilenum == 0x19) || (tilenum == 13) || (tilenum == 14) || (tilenum == 3) || (tilenum == 11) || (tilenum == 1) || (tilenum == 12)){
        boby=boby+4;
        jumpheight--;
      }
      if((tilenum != 0x00) && (tilenum != 0x18) && (tilenum != 0x19) && (tilenum != 13) && (tilenum != 14) && (tilenum != 3) && (tilenum != 11) && (tilenum != 1) && (tilenum != 12)){
	jumpable = 0;
      }
      if(direction == 2) {
        move_sprite(0,bobx+8,boby);
        move_sprite(1,bobx,boby);
        move_sprite(2,bobx+8,boby+8);
        move_sprite(3,bobx,boby+8);
        move_sprite(4,bobx+8,boby+16);
        move_sprite(5,bobx,boby+16);
      }
      if(direction == 1) {
        move_sprite(0,bobx,boby);
        move_sprite(1,bobx+8,boby);
        move_sprite(2,bobx,boby+8);
        move_sprite(3,bobx+8,boby+8);
        move_sprite(4,bobx,boby+16);
        move_sprite(5,bobx+8,boby+16);
      }
    }
    if((jumpheight < 19) && (jumpable == 1)) {
      boby=boby-4;
      jumpheight++;
      temp2 = (pixelmoved / 8) + (bobx / 8);
      if(temp2 > 31) temp2 = temp2 - 32;
      get_bkg_tiles(temp2,boby / 8 - 1,1,1,&tilenum);
      if(tilenum == 8) {
          jumpable = 2;
          set_bkg_tiles(temp2,boby / 8 - 2,2,2,zero);
          coins++;
          if(coins == 10) {
            coins = 0;
            lives++;
  	    if(lives == 9) set_sprite_tile(33,48);
	    if(lives == 8) set_sprite_tile(33,47);
	    if(lives == 7) set_sprite_tile(33,46);
	    if(lives == 6) set_sprite_tile(33,45);
	    if(lives == 5) set_sprite_tile(33,44);
	    if(lives == 4) set_sprite_tile(33,43);
	    if(lives == 3) set_sprite_tile(33,42);
	    if(lives == 2) set_sprite_tile(33,41);
          }
  	  if(coins == 9) set_sprite_tile(35,48);
	  if(coins == 8) set_sprite_tile(35,47);
	  if(coins == 7) set_sprite_tile(35,46);
	  if(coins == 6) set_sprite_tile(35,45);
	  if(coins == 5) set_sprite_tile(35,44);
	  if(coins == 4) set_sprite_tile(35,43);
	  if(coins == 3) set_sprite_tile(35,42);
	  if(coins == 2) set_sprite_tile(35,41);
	  if(coins == 1) set_sprite_tile(35,40);
	  if(coins == 0) set_sprite_tile(35,39);
      }
      if((tilenum != 00) && (tilenum != 11) && (tilenum != 1) && (tilenum != 12) && (tilenum != 13) && (tilenum != 14) && (tilenum < 30)) jumpable = 2;
      if(direction == 2) {
        move_sprite(0,bobx+8,boby);
        move_sprite(1,bobx,boby);
        move_sprite(2,bobx+8,boby+8);
        move_sprite(3,bobx,boby+8);
        move_sprite(4,bobx+8,boby+16);
        move_sprite(5,bobx,boby+16);
      }
      if(direction == 1) {
        move_sprite(0,bobx,boby);
        move_sprite(1,bobx+8,boby);
        move_sprite(2,bobx,boby+8);
        move_sprite(3,bobx+8,boby+8);
        move_sprite(4,bobx,boby+16);
        move_sprite(5,bobx+8,boby+16);
      }
    }
    if((jumpheight == 19) && (jumpable == 1)) jumpable = 2;

    if(joypad() == J_UP) {
      temp2 = (pixelmoved / 8) + (bobx / 8);
      if(temp2 > 31) temp2 = temp2 - 32;
      get_bkg_tiles(temp2,boby / 8,1,1,&tilenum);
      if(tilenum == 3) {
	level++;
        if(level == 1) set_sprite_tile(30,41);
        if(level == 2) set_sprite_tile(30,42);
        if(level == 3) set_sprite_tile(30,43);
        if(level == 4) set_sprite_tile(30,44);
        bobx = 64;
        boby = 120;
        standing = 1;
        jumpheight = 0;
        jumpable = 0;
        doshit = 0;
        scrollnum = 0;
        tilenum = 0;
        scrollcnt = 0;
	move_bkg(0,0);
	pixelmoved = 0;
	if(direction == 1) {
            move_sprite(0,bobx,boby);
            move_sprite(1,bobx+8,boby);
            move_sprite(2,bobx,boby+8);
            move_sprite(3,bobx+8,boby+8);
            move_sprite(4,bobx,boby+16);
            move_sprite(5,bobx+8,boby+16);		
	}
	if(direction == 2) {
            move_sprite(0,bobx+8,boby);
            move_sprite(1,bobx,boby);
            move_sprite(2,bobx+8,boby+8);
            move_sprite(3,bobx,boby+8);
            move_sprite(4,bobx+8,boby+16);
            move_sprite(5,bobx,boby+16);
	}
        renderlevel();
      }
    }
 
    // check for entrance to warpzone
    if(joypad() == J_DOWN) {
      temp2 = (pixelmoved / 8) + (bobx / 8);
      if(temp2 > 31) temp2 = temp2 - 32;
      get_bkg_tiles(temp2,boby / 8 + 1,1,1,&tilenum);
      if(tilenum == 15) {
	for(temp2 = 20; temp2 != 0; temp2--) {
          boby++;
	  if(direction == 1) {
            move_sprite(0,bobx,boby);
            move_sprite(1,bobx+8,boby);
            move_sprite(2,bobx,boby+8);
            move_sprite(3,bobx+8,boby+8);
            move_sprite(4,bobx,boby+16);
            move_sprite(5,bobx+8,boby+16);		
	  }
	  if(direction == 2) {
            move_sprite(0,bobx+8,boby);
            move_sprite(1,bobx,boby);
            move_sprite(2,bobx+8,boby+8);
            move_sprite(3,bobx,boby+8);
            move_sprite(4,bobx+8,boby+16);
            move_sprite(5,bobx,boby+16);
	  }
          delay(10);
        }
	level++;
        if(level == 1) set_sprite_tile(30,41);
        if(level == 2) set_sprite_tile(30,42);
        if(level == 3) set_sprite_tile(30,43);
        if(level == 4) set_sprite_tile(30,44);
        bobx = 64;
        boby = 120;
        standing = 1;
        jumpheight = 0;
        jumpable = 0;
        doshit = 0;
        scrollnum = 0;
        tilenum = 0;
        scrollcnt = 0;
	move_bkg(0,0);
	pixelmoved = 0;
	if(direction == 1) {
            move_sprite(0,bobx,boby);
            move_sprite(1,bobx+8,boby);
            move_sprite(2,bobx,boby+8);
            move_sprite(3,bobx+8,boby+8);
            move_sprite(4,bobx,boby+16);
            move_sprite(5,bobx+8,boby+16);		
	}
	if(direction == 2) {
            move_sprite(0,bobx+8,boby);
            move_sprite(1,bobx,boby);
            move_sprite(2,bobx+8,boby+8);
            move_sprite(3,bobx,boby+8);
            move_sprite(4,bobx+8,boby+16);
            move_sprite(5,bobx,boby+16);
	}
        renderlevel();
      }
    }    

    // left-right movement
    if(joypad() == 0x00) {
          set_sprite_tile(4,5);
          set_sprite_tile(5,6);
          standing = 5;
    }

    if(joypad() & J_LEFT) {
      direction = 2;
      if(bobx > 10) {
        bobx = bobx - 2;
        DISPLAY_OFF;
        set_sprite_prop(0,spritepalette[0]+S_FLIPX);
        set_sprite_prop(1,spritepalette[0]+S_FLIPX);
        set_sprite_prop(2,spritepalette[0]+S_FLIPX);
        set_sprite_prop(3,spritepalette[0]+S_FLIPX);
        set_sprite_prop(4,spritepalette[0]+S_FLIPX);
        set_sprite_prop(5,spritepalette[0]+S_FLIPX);
        DISPLAY_ON;
        move_sprite(0,bobx+8,boby);
        move_sprite(1,bobx,boby);
        move_sprite(2,bobx+8,boby+8);
        move_sprite(3,bobx,boby+8);
        move_sprite(4,bobx+8,boby+16);
        move_sprite(5,bobx,boby+16);
        if(standing == 10) {
          set_sprite_tile(4,5);
          set_sprite_tile(5,6);
        }
        if(standing == 5) {
          standing--;
          set_sprite_tile(4,7);
          set_sprite_tile(5,8);
        };
        standing--;
        if(standing == 0) standing = 10;
        temp2 = (pixelmoved / 8) + (bobx / 8);
        if(temp2 > 31) temp2 = temp2 - 32;
        get_bkg_tiles(temp2,boby / 8 + 1,1,1,&tilenum);
	if((tilenum == 0x00) && (jumpable == 0)) jumpable = 2;
      }
    }
    if(joypad() & J_RIGHT) {
      direction = 1;
      if(bobx < 160) {
        if(bobx < 100) bobx = bobx + 2;
	if(bobx > 99) scrollnum=scrollnum+2;
        DISPLAY_OFF;
        set_sprite_prop(0,spritepalette[0]);
        set_sprite_prop(1,spritepalette[0]);
        set_sprite_prop(2,spritepalette[0]);
        set_sprite_prop(3,spritepalette[0]);
        set_sprite_prop(4,spritepalette[0]);
        set_sprite_prop(5,spritepalette[0]);
        DISPLAY_ON;
        move_sprite(0,bobx,boby);
        move_sprite(1,bobx+8,boby);
        move_sprite(2,bobx,boby+8);
        move_sprite(3,bobx+8,boby+8);
        move_sprite(4,bobx,boby+16);
        move_sprite(5,bobx+8,boby+16);
        if(standing == 10) {
          set_sprite_tile(4,5);
          set_sprite_tile(5,6);
        }
        if(standing == 5) {
          standing--;
          set_sprite_tile(4,7);
          set_sprite_tile(5,8);
        };
        standing--;
        if(standing == 0) standing = 10;
        temp2 = (pixelmoved / 8) + (bobx / 8);
        if(temp2 > 31) temp2 = temp2 - 32;
        get_bkg_tiles(temp2,boby / 8 + 1,1,1,&tilenum);
	if((tilenum == 0x00) && (jumpable == 0)) jumpable = 2;
      }
    }
	
    // Engine speed control
    delay(15);
  }
  reset();
  return(0);
}

void vblint(void)
{
	disable_interrupts();
        if(scrollnum != 0) {
	  if(level == 0) if(tilenum != 255) scroll_bkg(1,0);
	  if(level == 1) if(tilenum != 255) scroll_bkg(1,0);
	  if(level == 2) if(tilenum != 255) scroll_bkg(1,0);
	  if(level == 3) if(tilenum != 255) scroll_bkg(1,0);
	  if(level == 4) if(tilenum != 255) scroll_bkg(1,0);
	  if(level == 100) if(tilenum != 255) scroll_bkg(1,0);
          scrollnum--;
	  scrollcnt = scrollcnt + 1;
	  pixelmoved++;
          if(scrollcnt == 8) {
		scrollcnt = 0;
		if(level == 0) if(tilenum != 255) updatelevel();
		if(level == 1) if(tilenum != 255) updatelevel();
		if(level == 2) if(tilenum != 255) updatelevel();
		if(level == 3) if(tilenum != 255) updatelevel();
		if(level == 4) if(tilenum != 255) updatelevel();
		if(level == 100) if(tilenum != 255) updatelevel();
	  }
	}
	enable_interrupts();
}

void renderlevel()
{
	for(tilenum=0;tilenum < 32; tilenum++) {
		if(level == 0) renderrow(tilenum, level1[tilenum]);
		if(level == 1) renderrow(tilenum, level2[tilenum]);
		if(level == 2) renderrow(tilenum, level3[tilenum]);
		if(level == 3) renderrow(tilenum, level4[tilenum]);
		if(level == 4) renderrow(tilenum, level5[tilenum]);
		if(level == 100) renderrow(tilenum, level100[tilenum]);
	}
	if(level == 1)  set_bkg_palette( 0, 3, &backgroundpalette2[0] );
	if(level == 2)  set_bkg_palette( 0, 3, &backgroundpalette[0] );

/*	if(level == 3)  set_bkg_palette( 0, 3, &backgroundpalette3[0] );
	if(level == 4)  set_bkg_palette( 0, 3, &backgroundpalette2[0] );
	if(level == 6)  set_bkg_palette( 0, 3, &backgroundpalette[0] );
*/
}

void updatelevel()
{
	int temp;
	if(level == 0) {
		temp = (pixelmoved / 8);
		if(temp == 0) temp = 32;
		temp--;
		renderrow(temp,level1[tilenum]);
		if(tilenum == 255) tilenum--;
	}
	if(level == 1) {
		temp = (pixelmoved / 8);
		if(temp == 0) temp = 32;
		temp--;
		renderrow(temp,level2[tilenum]);
		if(tilenum == 255) tilenum--;
	}
	if(level == 2) {
		temp = (pixelmoved / 8);
		if(temp == 0) temp = 32;
		temp--;
		renderrow(temp,level3[tilenum]);
		if(tilenum == 255) tilenum--;
	}
	if(level == 3) {
		temp = (pixelmoved / 8);
		if(temp == 0) temp = 32;
		temp--;
		renderrow(temp,level4[tilenum]);
		if(tilenum == 255) tilenum--;
	}
	if(level == 4) {
		temp = (pixelmoved / 8);
		if(temp == 0) temp = 32;
		temp--;
		renderrow(temp,level5[tilenum]);
		if(tilenum == 255) tilenum--;
	}
        if(level == 100) {
		temp = (pixelmoved / 8);
		if(temp == 0) temp = 32;
		temp--;
		renderrow(temp,level100[tilenum]);
		if(tilenum == 255) tilenum--;
        }
	tilenum++;
}


