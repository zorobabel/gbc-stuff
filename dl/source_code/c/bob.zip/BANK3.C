// Bank 3 - Level rendering and metatile data

#include <gb.h>

/*
Metatile map
0 = blank
1 = cobbled stone floor
2 = cobbled stone floor and platform
3 = left question box over cobbled stone
4 = right question box over cobbled stone
5 = cobbled stone platform hovering
6 = cobbled stone and left base of hill
7 = cobbled stone and left hill at medium height
8 = cobbled stone and left hill at full height
9 = cobbled stone and right hill at full height
10 = cobbled stone and right hill at medium height
11 = cobbled stone and right hill base
12 = cobbled stone and left pipe
13 = cobbled stone and right pipe
14 = cobbled stone and left cloud start
14 = cobbled stone and medium of cloud
16 = cobbled stone and right cloud end
17 = blank with left cloud start
18 = blank with medium of cloud
19 = blank with right end of cloud
20 = brick floor
21 = brick floor with brick platform
22 = brick floor and left question mark
23 = brick floor and right question mark
24 = brick floor hovering
25 = brick floor and left base of hill
26 = brick floor and left hill at medium height
27 = brick floor and left hill at full height
28 = brick floor and right hill at full height
29 = brick floor and right hill at medium height
30 = brick floor and right hill base
31 = brick floor and left pipe
32 = brick floor and right pipe
33 = brick floor and left cloud start
34 = brick floor and cloud middle
35 = brick floor and right cloud end
36 = psych floor
37 = psych floor with psych platform
38 = psych floor with left ?
39 = psych floor with right ?
40 = psych floor hovering
41 = psych floor and left pipe
42 = psych floor and right pipe
43 = psych floor with psych roof
44 = psych floor with psych platform and psych roof
45 = blank with low left cloud start 
46 = blank with low middle cloud
47 = blank with low right cloud end
48 = castle high wall
49 = castle wall
50 = castle door
*/

unsigned char meta0[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
};
unsigned char meta1[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5
};
unsigned char meta2[] = {
0,0,0,0,0,0,0,0,5,5,0,0,0,0,0,0,5,5
};
unsigned char meta3[] = {
0,0,0,0,0,0,0,0,6,8,0,0,0,0,0,0,5,5
};
unsigned char meta4[] = {
0,0,0,0,0,0,0,0,7,9,0,0,0,0,0,0,5,5
};
unsigned char meta5[] = {
0,0,0,0,0,0,0,0,5,5,0,0,0,0,0,0,0,0
};
unsigned char meta6[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,5,5
};
unsigned char meta7[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,1,5,5
};
unsigned char meta8[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,11,1,1,5,5
};
unsigned char meta9[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,12,1,1,5,5
};
unsigned char meta10[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,1,5,5
};
unsigned char meta11[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,5,5
};
unsigned char meta12[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,15,17,17,5,5
};
unsigned char meta13[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,16,18,18,5,5
};
unsigned char meta14[] = {
0,0,0,0,13,0,0,0,0,0,0,0,0,0,0,0,5,5
};
unsigned char meta15[] = {
0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,5,5
};
unsigned char meta16[] = {
0,0,0,0,14,0,0,0,0,0,0,0,0,0,0,0,5,5
};
unsigned char meta17[] = {
0,0,0,0,13,0,0,0,0,0,0,0,0,0,0,0,0,0
};
unsigned char meta18[] = {
0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0
};
unsigned char meta19[] = {
0,0,0,0,14,0,0,0,0,0,0,0,0,0,0,0,0,0
};
unsigned char meta20[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4
};
unsigned char meta21[] = {
0,0,0,0,0,0,0,0,4,4,0,0,0,0,0,0,4,4
};
unsigned char meta22[] = {
0,0,0,0,0,0,0,0,6,8,0,0,0,0,0,0,4,4
};
unsigned char meta23[] = {
0,0,0,0,0,0,0,0,7,9,0,0,0,0,0,0,4,4
};
unsigned char meta24[] = {
0,0,0,0,0,0,0,0,4,4,0,0,0,0,0,0,0,0
};
unsigned char meta25[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,4,4
};
unsigned char meta26[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,11,1,4,4
};
unsigned char meta27[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,11,1,1,4,4
};
unsigned char meta28[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,12,1,1,4,4
};
unsigned char meta29[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,1,4,4
};
unsigned char meta30[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,4,4
};
unsigned char meta31[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,15,17,17,4,4
};
unsigned char meta32[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,16,18,18,4,4
};
unsigned char meta33[] = {
0,0,13,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4
};
unsigned char meta34[] = {
0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4
};
unsigned char meta35[] = {
0,0,14,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4
};
unsigned char meta36[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10
};
unsigned char meta37[] = {
0,0,0,0,0,0,0,0,10,10,0,0,0,0,0,0,10,10
};
unsigned char meta38[] = {
0,0,0,0,0,0,0,0,6,8,0,0,0,0,0,0,10,10
};
unsigned char meta39[] = {
0,0,0,0,0,0,0,0,7,9,0,0,0,0,0,0,10,10
};
unsigned char meta40[] = {
0,0,0,0,0,0,0,0,10,10,0,0,0,0,0,0,0,0
};
unsigned char meta41[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,15,17,17,10,10
};
unsigned char meta42[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,16,18,18,10,10
};
unsigned char meta43[] = {
10,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10
};
unsigned char meta44[] = {
10,10,0,0,0,0,0,0,10,10,0,0,0,0,0,0,0,0
};
unsigned char meta45[] = {
0,0,0,0,0,0,0,0,0,0,0,13,0,0,0,0,0,0
};
unsigned char meta46[] = {
0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0
};
unsigned char meta47[] = {
0,0,0,0,0,0,0,0,0,0,0,14,0,0,0,0,0,0
};
unsigned char meta48[] = {
0,0,0,0,0,0,4,4,4,4,4,4,4,4,4,4,5,5
};
unsigned char meta49[] = {
0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,4,5,5
};
unsigned char meta50[] = {
0,0,0,0,0,0,4,4,4,4,4,19,3,3,3,3,5,5
};

void renderrow(unsigned int x, unsigned int metanum)
{
  if(metanum == 0) set_bkg_tiles(x,0,1,18,meta0);  
  if(metanum == 1) set_bkg_tiles(x,0,1,18,meta1);  
  if(metanum == 2) set_bkg_tiles(x,0,1,18,meta2);  
  if(metanum == 3) set_bkg_tiles(x,0,1,18,meta3);  
  if(metanum == 4) set_bkg_tiles(x,0,1,18,meta4);  
  if(metanum == 5) set_bkg_tiles(x,0,1,18,meta5);  
  if(metanum == 6) set_bkg_tiles(x,0,1,18,meta6);  
  if(metanum == 7) set_bkg_tiles(x,0,1,18,meta7);  
  if(metanum == 8) set_bkg_tiles(x,0,1,18,meta8);  
  if(metanum == 9) set_bkg_tiles(x,0,1,18,meta9);  
  if(metanum == 10) set_bkg_tiles(x,0,1,18,meta10);  
  if(metanum == 11) set_bkg_tiles(x,0,1,18,meta11);  
  if(metanum == 12) set_bkg_tiles(x,0,1,18,meta12);  
  if(metanum == 13) set_bkg_tiles(x,0,1,18,meta13);  
  if(metanum == 14) set_bkg_tiles(x,0,1,18,meta14);  
  if(metanum == 15) set_bkg_tiles(x,0,1,18,meta15);  
  if(metanum == 16) set_bkg_tiles(x,0,1,18,meta16);  
  if(metanum == 17) set_bkg_tiles(x,0,1,18,meta17);  
  if(metanum == 18) set_bkg_tiles(x,0,1,18,meta18);  
  if(metanum == 19) set_bkg_tiles(x,0,1,18,meta19);  
  if(metanum == 20) set_bkg_tiles(x,0,1,18,meta20);  
  if(metanum == 21) set_bkg_tiles(x,0,1,18,meta21);  
  if(metanum == 22) set_bkg_tiles(x,0,1,18,meta22);  
  if(metanum == 23) set_bkg_tiles(x,0,1,18,meta23);  
  if(metanum == 24) set_bkg_tiles(x,0,1,18,meta24);  
  if(metanum == 25) set_bkg_tiles(x,0,1,18,meta25);  
  if(metanum == 26) set_bkg_tiles(x,0,1,18,meta26);  
  if(metanum == 27) set_bkg_tiles(x,0,1,18,meta27);  
  if(metanum == 28) set_bkg_tiles(x,0,1,18,meta28);  
  if(metanum == 29) set_bkg_tiles(x,0,1,18,meta29);  
  if(metanum == 30) set_bkg_tiles(x,0,1,18,meta30);
  if(metanum == 31) set_bkg_tiles(x,0,1,18,meta31);
  if(metanum == 32) set_bkg_tiles(x,0,1,18,meta32);
  if(metanum == 33) set_bkg_tiles(x,0,1,18,meta33);
  if(metanum == 34) set_bkg_tiles(x,0,1,18,meta34);
  if(metanum == 35) set_bkg_tiles(x,0,1,18,meta35);
  if(metanum == 36) set_bkg_tiles(x,0,1,18,meta36);
  if(metanum == 37) set_bkg_tiles(x,0,1,18,meta37);
  if(metanum == 38) set_bkg_tiles(x,0,1,18,meta38);
  if(metanum == 39) set_bkg_tiles(x,0,1,18,meta39);
  if(metanum == 40) set_bkg_tiles(x,0,1,18,meta40);
  if(metanum == 41) set_bkg_tiles(x,0,1,18,meta41);
  if(metanum == 42) set_bkg_tiles(x,0,1,18,meta42);
  if(metanum == 43) set_bkg_tiles(x,0,1,18,meta43);
  if(metanum == 44) set_bkg_tiles(x,0,1,18,meta44);
  if(metanum == 45) set_bkg_tiles(x,0,1,18,meta45);
  if(metanum == 46) set_bkg_tiles(x,0,1,18,meta46);
  if(metanum == 47) set_bkg_tiles(x,0,1,18,meta47);
  if(metanum == 48) set_bkg_tiles(x,0,1,18,meta48);
  if(metanum == 49) set_bkg_tiles(x,0,1,18,meta49);
  if(metanum == 50) set_bkg_tiles(x,0,1,18,meta50);
}
