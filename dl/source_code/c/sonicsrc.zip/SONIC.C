/*
Sonic 
A quick Gameboy Color demo
Written by Jason
http://www.gbdev.org/news/

This demo should teach anyone who knows C and GBDK how to use a window
to make multiparallex scrolling. It should also help teach anyone
who doesn't know GBDK some of the basic things, like
	Display a picture
	GBC support
	Sprites
	VBlank Routines

There is 1 proble. pcx2gb kinda fucked up the Sonic tiles, but it's
still playable.

I doubt I will ever turn this into a game, so feel free to take the
source and write a sonic GBC game out of it.
*/

// include gb header file
#include <gb.h>
// include color defines, available at my site
#include <colors.h>

// include title pic data
#include "title.dat"
#include "title.map"

// include sonic data files
#include "1.dat"		// 4x6
#include "2.dat"		// 4x6
#include "3.dat"		// 4x6
#include "4.dat"		// 4x6
#include "5.dat"		// 4x6
#include "6.dat"		// 4x6
#include "7.dat"		// 5x5
#include "8.dat"		// 4x6
#include "9.dat"		// 5x6
#include "10.dat"		// 5x6

// and the background files
#include "bg.dat"
#include "bg.map"

// sprite palette
UWORD spritepal[] = {
white,orange,blue,black
};

// title palette
UWORD titlepal[] = {
white,orange,blue,darkblue
};

// background palette
UWORD bgpal[] = {
green,darkgreen,yellow,brown,
};

// window data
unsigned char windata[] = {
62,255,7,255,225,255,7,255,62,255,112,255,195,255,112,255,
85,0,170,0,85,0,170,85,62,255,112,255,195,255,112,255,
85,0,170,0,85,0,170,0,85,0,170,0,85,0,170,0,
};

// window map 1
unsigned char windowmap1[] = {
252,252,252,252,252,252,252,252,252,252,252,252,252,252,252,252,
252,252,252,252,252,252,252,252,252,252,252,252,252,252,252,252,
252,252,252,252,252,252,252,252,252,252,252,252,252,252,252,252,
252,252,252,252,252,252,252,252,252,252,252,252,252,252,252,252,
251,251,251,251,251,251,251,251,251,251,251,251,251,251,251,251,
251,251,251,251,251,251,251,251,251,251,251,251,251,251,251,251,
};

// window map 2
unsigned char windowmap2[] = {
250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,
250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,
};

// sonic run or not?
unsigned int run;

// sonic's x and y coordinates
unsigned int x, y;

// scroll counter
unsigned int scrollcnt;

// counter
unsigned int counter;

// vblank procedures
void vblint(void);

// sonic graphic loading routines
void sonic46(void);
void sonic55(void);
void sonic56(void);

// clear screen
void clearscreen(void);

// blank used for cleaning screen
unsigned char clearshit[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};
unsigned char unclearshit[] = {
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
};


main()
{
	unsigned int temp;

	// turn the display off
	DISPLAY_OFF;

	// load the background palette
	set_bkg_palette(0,2,&titlepal[0] );  

	// turn to video bank 0
	VBK_REG = 0;

	// set the background data
	set_bkg_data(0,228,titledata);

	// set the background tiles
	set_bkg_tiles(0,2,20,14,titlemap);

	// turn the display on
	DISPLAY_ON;

	// show the background
	SHOW_BKG;

	// wait until start is pressed
	waitpad(J_START);

	// turn the screen off
	DISPLAY_OFF;

	// load correct tile in sprite
	for(temp = 0; temp != 40; temp++) {
		set_sprite_tile(temp,temp);
	}

	// set the sprite palette
	set_sprite_palette(0,2,&spritepal[0]);	

	// clear the scrollcnt
	scrollcnt = 0;

	x = 80;
	y = 84;
	clearscreen();

	// turn to video bank 1
	VBK_REG = 1;

	// set bottom palette info
	for(temp=0;temp!=8;temp++) {
		set_bkg_tiles(0,temp+10,32,1,unclearshit);
	}

	// set the background palette
	set_bkg_palette(0,2,&bgpal[0] );  


	// turn to video bank 0
	VBK_REG = 0;

	// move window to corner of screen
	move_win(0,100);

	// set background data
	set_bkg_data(250,3,windata);

	// set window data
	set_win_data(250,3,windata);

	// set window tile data
	set_win_tiles(0,0,32,3,windowmap1);

	// set window tile data pt 2
	for(temp=0;temp!=8;temp++) {
		set_win_tiles(0,temp+3,32,1,windowmap2);
	}

	// set the background data
	set_bkg_data(0,192,bgdata);

	// set the background tiles
	set_bkg_tiles(28,0,14,15,bgmap);
	set_bkg_tiles(14,0,14,15,bgmap);
	set_bkg_tiles(0,0,14,15,bgmap);

	// turn the screen on
	DISPLAY_ON;

	// show the sprites
	SHOW_SPRITES;

	// show the background
	SHOW_BKG;

	// test
	scroll_win(8,0);

	// show the window
	SHOW_WIN;

	// disable the interrupts
	disable_interrupts();

	// add a vblank interrupt routine
	add_vbl(vblint);

	// enable the interrupts
	enable_interrupts();

	// infinite loop
	while(!0) {
		if(joypad() & J_RIGHT) run=1;
		else run = 0;
	}

	// clear video data
	VBK_REG = 1;
	clearscreen();
	VBK_REG = 0;
	clearscreen();

	return(0);

}

void sonic46(void)
{
	move_sprite(0,x,y);
	move_sprite(1,x+8,y);
	move_sprite(2,x+16,y);
//	move_sprite(3,x+24,y);
	move_sprite(4,x,y+8);
	move_sprite(5,x+8,y+8);
	move_sprite(6,x+16,y+8);
//	move_sprite(7,x+24,y+8);
	move_sprite(8,x,y+16);
	move_sprite(9,x+8,y+16);
	move_sprite(10,x+16,y+16);
//	move_sprite(11,x+24,y+16);
	move_sprite(12,x,y+24);
	move_sprite(13,x+8,y+24);
	move_sprite(14,x+16,y+24);
//	move_sprite(15,x+24,y+24);
	move_sprite(16,x,y+32);
	move_sprite(17,x+8,y+32);
	move_sprite(18,x+16,y+32);
//	move_sprite(19,x+24,y+32);
//	move_sprite(20,x,y+40);
//	move_sprite(21,x+8,y+40);
//	move_sprite(22,x+16,y+40);
//	move_sprite(23,x+24,y+40);

	move_sprite(24,222,222);
	move_sprite(25,222,222);
	move_sprite(26,222,222);
	move_sprite(27,222,222);
	move_sprite(28,222,222);
	move_sprite(29,222,222);

}

void sonic55(void)
{
	move_sprite(0,x,y);
	move_sprite(1,x+8,y);
	move_sprite(2,x+16,y);
	move_sprite(3,x+24,y);
//	move_sprite(4,x+32,y);
	move_sprite(5,x,y+8);
	move_sprite(6,x+8,y+8);
	move_sprite(7,x+16,y+8);
	move_sprite(8,x+24,y+8);
//	move_sprite(9,x+32,y+8);
	move_sprite(10,x,y+16);
	move_sprite(11,x+8,y+16);
	move_sprite(12,x+16,y+16);
	move_sprite(13,x+24,y+16);
//	move_sprite(14,x+32,y+16);
	move_sprite(15,x,y+24);
	move_sprite(16,x+8,y+24);
	move_sprite(17,x+16,y+24);
	move_sprite(18,x+24,y+24);
//	move_sprite(19,x+32,y+24);
//	move_sprite(20,x,y+32);
//	move_sprite(21,x+8,y+32);
//	move_sprite(22,x+16,y+32);
//	move_sprite(23,x+24,y+32);
//	move_sprite(24,x+32,y+32);

	move_sprite(25,222,222);
	move_sprite(26,222,222);
	move_sprite(27,222,222);
	move_sprite(28,222,222);
	move_sprite(29,222,222);

}

void sonic56(void)
{
	move_sprite(0,x,y);
	move_sprite(1,x+8,y);
	move_sprite(2,x+16,y);
	move_sprite(3,x+24,y);
//	move_sprite(4,x+32,y);
	move_sprite(5,x,y+8);
	move_sprite(6,x+8,y+8);
	move_sprite(7,x+16,y+8);
	move_sprite(8,x+24,y+8);
//	move_sprite(9,x+32,y+8);
	move_sprite(10,x,y+16);
	move_sprite(11,x+8,y+16);
	move_sprite(12,x+16,y+16);
	move_sprite(13,x+24,y+16);
//	move_sprite(14,x+32,y+16);
	move_sprite(15,x,y+24);
	move_sprite(16,x+8,y+24);
	move_sprite(17,x+16,y+24);
	move_sprite(18,x+24,y+24);
//	move_sprite(19,x+32,y+24);
	move_sprite(20,x,y+32);
	move_sprite(21,x+8,y+32);
	move_sprite(22,x+16,y+32);
	move_sprite(23,x+24,y+32);
//	move_sprite(24,x+32,y+32);
//	move_sprite(25,x,y+40);
//	move_sprite(26,x+8,y+40);
//	move_sprite(27,x+16,y+40);
//	move_sprite(28,x+24,y+40);
//	move_sprite(29,x+32,y+40);
}


void vblint(void)
{
	// to prevent overflow, di
	disable_interrupts();

	// increase counter
	counter++;

	if(run == 1) {
		// scroll background
		scroll_bkg(2,0);

		// scroll window
		scroll_win(-1,0);
		scrollcnt++;
		if(scrollcnt == 8) {
			scroll_win(8,0);
			scrollcnt = 0;
		}

		// draw sonic running
		if(counter == 4) {
			set_sprite_data(0,30,sonic7);
			sonic55();
		}
		// draw sonic running
		if(counter == 8) {
			set_sprite_data(0,30,sonic8);
			sonic46();
		}
		// draw sonic running
		if(counter == 12)  {
			set_sprite_data(0,30,sonic9);
			sonic56();
		}
		// draw sonic running
		if(counter == 16)  {
			set_sprite_data(0,30,sonic10);
			sonic56();
			counter = 0;
		}

	}


	// if sonic is standing still
	if(run == 0) {
		// draw him standing still
		if(counter == 2) {
			set_sprite_data(0,30,sonic1);
			sonic46();
		}

		// draw him standing still
		if(counter == 4) {
			set_sprite_data(0,30,sonic2);
			sonic46();
		}

		// draw him standing still
		if(counter == 6) {
			set_sprite_data(0,30,sonic3);
			sonic46();
		}

		// draw him standing still
		if(counter == 8) {
			set_sprite_data(0,30,sonic4);
			sonic46();
		}		

		// draw him standing still
		if(counter == 10) {
			set_sprite_data(0,30,sonic5);
			sonic46();
		}

		// draw him standing still
		if(counter == 12) {
			set_sprite_data(0,30,sonic4);
			sonic46();
		}		

		// draw him standing still
		if(counter == 16) {
			set_sprite_data(0,30,sonic6);
			sonic46();
			counter = 0;
		}

	}

	// re-enable the interrupts
	enable_interrupts();

}

void clearscreen(void)
{
	unsigned int x;

	// clear screen
	for(x=0;x!=32;x++) {
		set_bkg_tiles(0,x,32,1,clearshit);
	}
}
