// Maze Runner
// Written by Jason
// drunk-ass@beer.com
//
// Compiled with GBDK 2.94
//
// Terribly unoptimized. Terribly simplistic in nature.
// You can suck my dick if you don't like my shit.
//
// Runs great on a Gameboy or Gameboy Color
//
// While my game is really rather simple, with just a
// little bit of work you could put some badguys, music,
// etc. in here, as well as round the walls off so they
// look better, maybe texture them, etc. but i coded
// this in an hour and a half just to see what it would
// look like and what speeds i could get.
//
// The maze is 20x20, where every wall and the player
// itself occupy 1 square. you can easily make the map
// bigger or smaller, but you have to change all the
// * 20s in the source code. Map data is 1 byte per slot
// (wasteful I know).
// 0 = White
// 1 = Light
// 2 = Dark
// 3 = Black
// You can walk through white. The others use the 3 shades
// so you can see the wall move as you move up/down.
//
// The game renders 3 squares ahead. While one could easily
// up that to alot more, I am too lazy. This was just a test.
//
// If you can't figure something out, don't e-mail me.
// I commented as much as I felt like... =)
//
// Gameboy defines
#include <gb\gb.h>
// Alphabet (for direction header)
#include "alphabet.c"

// Subroutines/procedures
void Clear_Screen(void);
UBYTE Check_Joypad(void);
void Update_Screen(void);
void Update_Sprites(void);
void Init_Sprites(void);

// Player X = X location on map, Player Y = Y location on map,
// Z = Player Direction. 0 = Up, 1 = Down, 2 = Left, 3 = Right
UBYTE PlayerX, PlayerY, PlayerZ;
// Temp variables used to figure shit out
UWORD TempA, TempB;
UBYTE TempX, TempY;
UBYTE FillX, FillY;
// Speed_Control controls how fast the game plays
UBYTE Speed_Control;

// Palette to load for GBC hardware. Just a regular 4 shades...
const UWORD Palette[] = {
RGB(30,30,30),RGB(20,20,20),RGB(10,10,10),RGB(0,0,0),
RGB(0,0,0),RGB(10,10,10),RGB(20,20,20),RGB(30,30,30),
};
// red palette so you can read the direction easily on a gbc
const UWORD Sprite_Palette[] = {
RGB(30,0,0),RGB(30,0,0),RGB(30,0,0),RGB(30,0,0),
};

// black tilemap
const UBYTE Black[] = {
3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
};
// dark tilemap
const UBYTE Dark[] = {
2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
};
// light tilemap
const UBYTE Light[] = {
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
};
// white tilemap
const UBYTE White[] = {
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};

// game map. altering this makes a new maze
const UBYTE Map[] = {
2,1,2,3,2,1,2,3,2,1,2,3,2,1,2,3,2,1,2,3,
3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,
2,0,2,3,2,1,0,3,2,1,2,3,2,1,2,3,2,3,0,1,
1,0,1,2,3,2,0,2,0,0,0,0,0,0,0,0,0,2,0,2,
2,0,2,0,0,0,0,1,0,1,2,3,2,1,2,3,0,1,0,3,
3,0,3,0,3,2,1,2,0,2,3,2,1,2,3,2,1,2,0,2,
2,0,2,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,1,
1,0,1,2,3,2,1,2,3,2,1,2,3,2,1,2,3,2,1,2,
2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,3,0,3,
3,0,3,2,0,2,3,0,0,2,3,0,1,2,3,0,2,1,0,2,
2,0,2,0,1,0,2,0,1,0,0,0,0,3,0,0,3,2,0,1,
1,0,1,0,2,0,1,0,2,0,0,0,0,2,0,0,2,1,0,2,
2,0,2,0,0,0,2,0,3,0,0,0,0,1,0,0,0,0,0,3,
3,0,3,0,0,0,3,0,0,2,1,0,3,2,0,0,0,1,0,2,
2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,1,
1,0,1,2,3,2,1,2,3,0,3,2,1,2,3,1,0,1,0,2,
2,0,2,0,2,3,0,0,0,0,2,3,2,3,2,0,0,2,0,3,
3,0,3,0,1,2,0,0,0,0,0,0,1,0,0,0,0,3,0,2,
2,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
1,2,1,2,3,2,1,2,3,2,1,2,3,2,1,2,3,2,1,2,
};

// game's tiles. white, light, dark, black
unsigned char Tiles[] =
{
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,
  0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,
  0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,
  0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0xFF,
  0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
  0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF
};

main()
{
        UBYTE Loop, MTemp;

        // Initial values
        Loop = 0;
        Speed_Control = 100;
        PlayerX = 1;
        PlayerY = 5;
        PlayerZ = 0;
        
        // set initial palette
        set_bkg_palette(0,1,&Palette);
        set_bkg_data(0,4,Tiles);
        SHOW_BKG;
        Init_Sprites();

        // clear the screen
        Clear_Screen();
        // initial updates
        Update_Screen();
        Update_Sprites();

        // loop until reset
        while(Loop == 0) {
                // check the joypad
                MTemp = Check_Joypad();
                // if select is pressed, end the game loop
                if(MTemp & J_SELECT) Loop++;
                // if anything else is pressed, update the game screen
                if(MTemp != 0) {
                        Clear_Screen();
                        Update_Screen();
                        Update_Sprites();
                }
                // slow the game down to the desired speed
                delay(Speed_Control);
        }

        // prevent gb from crashing
        reset();
}

// clear_screen erases the old display
void Clear_Screen()
{
        UBYTE cx;

        // wait until it's ok to update the video ram
        wait_vbl_done();

        // call this 21 times 
        for(cx=0;cx!=21;cx++) {
                // clear 1 vertical line
                set_bkg_tiles(cx,0,1,20,White);
        }
}

// read the joypad and update the game accordingly
UBYTE Check_Joypad()
{
        UBYTE joy;

        // read the joypad
        joy = joypad();

        // turn left if left is pressed
        if(joy & J_LEFT) {
                switch(PlayerZ) {
                        case 0: PlayerZ = 2;
                                break;
                        case 1: PlayerZ = 3;
                                break;
                        case 2: PlayerZ = 1;
                                break;
                        case 3: PlayerZ = 0;
                                break;
                }
        }

        // turn right if right is pressed
        if(joy & J_RIGHT) {
                switch(PlayerZ) {
                        case 0: PlayerZ = 3;
                                break;
                        case 1: PlayerZ = 2;
                                break;
                        case 2: PlayerZ = 0;
                                break;
                        case 3: PlayerZ = 1;
                                break;
                }
        }

        // move forward if up is pressed
        if(joy & J_UP) {
                switch(PlayerZ) {
                        // the temp variables TempX and TempY hold the
                        // destination that the player hopes to travel.
                        // TempA is the destination tile in the map
                        // if TempA is zero, the player can move there
                        case 0: TempX = PlayerX;
                                TempY = PlayerY - 1;
                                TempA = (TempY * 20) + TempX;
                                if(Map[TempA] == 0) PlayerY--;
                                break;
                        case 1: TempX = PlayerX;
                                TempY = PlayerY + 1;
                                TempA = (TempY * 20) + TempX;
                                if(Map[TempA] == 0) PlayerY++;
                                break;
                        case 2: TempX = PlayerX - 1;
                                TempY = PlayerY;
                                TempA = (TempY * 20) + TempX;
                                if(Map[TempA] == 0) PlayerX--;
                                break;
                        case 3: TempX = PlayerX + 1;
                                TempY = PlayerY;
                                TempA = (TempY * 20) + TempX;
                                if(Map[TempA] == 0) PlayerX++;
                                break;
                }
        }

        // move backward if down is pressed
        if(joy & J_DOWN) {
                switch(PlayerZ) {
                        case 0: TempX = PlayerX;
                                TempY = PlayerY + 1;
                                TempA = (TempY * 20) + TempX;
                                if(Map[TempA] == 0) PlayerY++;
                                break;
                        case 1: TempX = PlayerX;
                                TempY = PlayerY - 1;
                                TempA = (TempY * 20) + TempX;
                                if(Map[TempA] == 0) PlayerY--;
                                break;
                        case 2: TempX = PlayerX + 1;
                                TempY = PlayerY;
                                TempA = (TempY * 20) + TempX;
                                if(Map[TempA] == 0) PlayerX++;
                                break;
                        case 3: TempX = PlayerX - 1;
                                TempY = PlayerY;
                                TempA = (TempY * 20) + TempX;
                                if(Map[TempA] == 0) PlayerX--;
                                break;
                }
        }

        // return what was read
        return(joy);
}

// update the display so it shows the latest updated screen
void Update_Screen()
{
        // make sure it's ok to update the graphics
        wait_vbl_done();

        switch(PlayerZ) {
        // First Step - Figure out which direction the player is facing
        // Second Step - Render closest wall to left
                case 0: TempX = PlayerX - 1;
                        TempY = PlayerY - 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(0,0,1,18,Light);
                                set_bkg_tiles(1,1,1,16,Light);
                                set_bkg_tiles(2,2,1,14,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(0,0,1,18,Dark);
                                set_bkg_tiles(1,1,1,16,Dark);
                                set_bkg_tiles(2,2,1,14,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(0,0,1,18,Black);
                                set_bkg_tiles(1,1,1,16,Black);
                                set_bkg_tiles(2,2,1,14,Black);
                        }
        // Third Step - Render middle wall on left
                        TempX = PlayerX - 1;
                        TempY = PlayerY - 2;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(3,3,1,12,Light);
                                set_bkg_tiles(4,4,1,10,Light);
                                set_bkg_tiles(5,5,1,8,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(3,3,1,12,Dark);
                                set_bkg_tiles(4,4,1,10,Dark);
                                set_bkg_tiles(5,5,1,8,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(3,3,1,12,Black);
                                set_bkg_tiles(4,4,1,10,Black);
                                set_bkg_tiles(5,5,1,8,Black);
                        }
        // Fourth Step - Render rear wall on left
                        TempX = PlayerX - 1;
                        TempY = PlayerY - 3;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(6,6,1,6,Light);
                                set_bkg_tiles(7,7,1,4,Light);
                                set_bkg_tiles(8,8,1,2,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(6,6,1,6,Dark);
                                set_bkg_tiles(7,7,1,4,Dark);
                                set_bkg_tiles(8,8,1,2,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(6,6,1,6,Black);
                                set_bkg_tiles(7,7,1,4,Black);
                                set_bkg_tiles(8,8,1,2,Black);
                        }
        // Fifth Step - Render closest wall to right
                        TempX = PlayerX + 1;
                        TempY = PlayerY - 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(19,0,1,18,Light);
                                set_bkg_tiles(18,1,1,16,Light);
                                set_bkg_tiles(17,2,1,14,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(19,0,1,18,Dark);
                                set_bkg_tiles(18,1,1,16,Dark);
                                set_bkg_tiles(17,2,1,14,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(19,0,1,18,Black);
                                set_bkg_tiles(18,1,1,16,Black);
                                set_bkg_tiles(17,2,1,14,Black);
                        }
        // Sixth Step - Render middle wall on left
                        TempX = PlayerX + 1;
                        TempY = PlayerY - 2;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(16,3,1,12,Light);
                                set_bkg_tiles(15,4,1,10,Light);
                                set_bkg_tiles(14,5,1,8,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(16,3,1,12,Dark);
                                set_bkg_tiles(15,4,1,10,Dark);
                                set_bkg_tiles(14,5,1,8,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(16,3,1,12,Black);
                                set_bkg_tiles(15,4,1,10,Black);
                                set_bkg_tiles(14,5,1,8,Black);
                        }
        // Seventh Step - Render rear wall on left
                        TempX = PlayerX + 1;
                        TempY = PlayerY - 3;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(13,6,1,6,Light);
                                set_bkg_tiles(12,7,1,4,Light);
                                set_bkg_tiles(11,8,1,2,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(13,6,1,6,Dark);
                                set_bkg_tiles(12,7,1,4,Dark);
                                set_bkg_tiles(11,8,1,2,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(13,6,1,6,Black);
                                set_bkg_tiles(12,7,1,4,Black);
                                set_bkg_tiles(11,8,1,2,Black);
                        }
        // Last Step - Check to see if there is a wall directly in the
        // player's face
                        // 1 of 3
                        TempX = PlayerX;
                        TempY = PlayerY - 3;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Black);
                                }
                        }
                        // 2 of 3
                        TempX = PlayerX;
                        TempY = PlayerY - 2;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Black);
                                }
                        }
                        // 3 of 3
                        TempX = PlayerX;
                        TempY = PlayerY - 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Black);
                                }
                        }
                        break;

                case 1: TempX = PlayerX + 1;
                        TempY = PlayerY + 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(0,0,1,18,Light);
                                set_bkg_tiles(1,1,1,16,Light);
                                set_bkg_tiles(2,2,1,14,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(0,0,1,18,Dark);
                                set_bkg_tiles(1,1,1,16,Dark);
                                set_bkg_tiles(2,2,1,14,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(0,0,1,18,Black);
                                set_bkg_tiles(1,1,1,16,Black);
                                set_bkg_tiles(2,2,1,14,Black);
                        }
                        TempX = PlayerX + 1;
                        TempY = PlayerY + 2;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(3,3,1,12,Light);
                                set_bkg_tiles(4,4,1,10,Light);
                                set_bkg_tiles(5,5,1,8,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(3,3,1,12,Dark);
                                set_bkg_tiles(4,4,1,10,Dark);
                                set_bkg_tiles(5,5,1,8,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(3,3,1,12,Black);
                                set_bkg_tiles(4,4,1,10,Black);
                                set_bkg_tiles(5,5,1,8,Black);
                        }
                        TempX = PlayerX + 1;
                        TempY = PlayerY + 3;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(6,6,1,6,Light);
                                set_bkg_tiles(7,7,1,4,Light);
                                set_bkg_tiles(8,8,1,2,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(6,6,1,6,Dark);
                                set_bkg_tiles(7,7,1,4,Dark);
                                set_bkg_tiles(8,8,1,2,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(6,6,1,6,Black);
                                set_bkg_tiles(7,7,1,4,Black);
                                set_bkg_tiles(8,8,1,2,Black);
                        }
                        TempX = PlayerX - 1;
                        TempY = PlayerY + 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(19,0,1,18,Light);
                                set_bkg_tiles(18,1,1,16,Light);
                                set_bkg_tiles(17,2,1,14,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(19,0,1,18,Dark);
                                set_bkg_tiles(18,1,1,16,Dark);
                                set_bkg_tiles(17,2,1,14,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(19,0,1,18,Black);
                                set_bkg_tiles(18,1,1,16,Black);
                                set_bkg_tiles(17,2,1,14,Black);
                        }
                        TempX = PlayerX - 1;
                        TempY = PlayerY + 2;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(16,3,1,12,Light);
                                set_bkg_tiles(15,4,1,10,Light);
                                set_bkg_tiles(14,5,1,8,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(16,3,1,12,Dark);
                                set_bkg_tiles(15,4,1,10,Dark);
                                set_bkg_tiles(14,5,1,8,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(16,3,1,12,Black);
                                set_bkg_tiles(15,4,1,10,Black);
                                set_bkg_tiles(14,5,1,8,Black);
                        }
                        TempX = PlayerX - 1;
                        TempY = PlayerY + 3;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(13,6,1,6,Light);
                                set_bkg_tiles(12,7,1,4,Light);
                                set_bkg_tiles(11,8,1,2,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(13,6,1,6,Dark);
                                set_bkg_tiles(12,7,1,4,Dark);
                                set_bkg_tiles(11,8,1,2,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(13,6,1,6,Black);
                                set_bkg_tiles(12,7,1,4,Black);
                                set_bkg_tiles(11,8,1,2,Black);
                        }
                        TempX = PlayerX;
                        TempY = PlayerY + 3;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Black);
                                }
                        }
                        TempX = PlayerX;
                        TempY = PlayerY + 2;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Black);
                                }
                        }
                        TempX = PlayerX;
                        TempY = PlayerY + 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Black);
                                }
                        }
                        break;

                case 2: TempX = PlayerX - 1;
                        TempY = PlayerY + 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(0,0,1,18,Light);
                                set_bkg_tiles(1,1,1,16,Light);
                                set_bkg_tiles(2,2,1,14,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(0,0,1,18,Dark);
                                set_bkg_tiles(1,1,1,16,Dark);
                                set_bkg_tiles(2,2,1,14,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(0,0,1,18,Black);
                                set_bkg_tiles(1,1,1,16,Black);
                                set_bkg_tiles(2,2,1,14,Black);
                        }
                        TempX = PlayerX - 2;
                        TempY = PlayerY + 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(3,3,1,12,Light);
                                set_bkg_tiles(4,4,1,10,Light);
                                set_bkg_tiles(5,5,1,8,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(3,3,1,12,Dark);
                                set_bkg_tiles(4,4,1,10,Dark);
                                set_bkg_tiles(5,5,1,8,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(3,3,1,12,Black);
                                set_bkg_tiles(4,4,1,10,Black);
                                set_bkg_tiles(5,5,1,8,Black);
                        }
                        TempX = PlayerX - 3;
                        TempY = PlayerY + 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(6,6,1,6,Light);
                                set_bkg_tiles(7,7,1,4,Light);
                                set_bkg_tiles(8,8,1,2,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(6,6,1,6,Dark);
                                set_bkg_tiles(7,7,1,4,Dark);
                                set_bkg_tiles(8,8,1,2,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(6,6,1,6,Black);
                                set_bkg_tiles(7,7,1,4,Black);
                                set_bkg_tiles(8,8,1,2,Black);
                        }
                        TempX = PlayerX - 1;
                        TempY = PlayerY - 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(19,0,1,18,Light);
                                set_bkg_tiles(18,1,1,16,Light);
                                set_bkg_tiles(17,2,1,14,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(19,0,1,18,Dark);
                                set_bkg_tiles(18,1,1,16,Dark);
                                set_bkg_tiles(17,2,1,14,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(19,0,1,18,Black);
                                set_bkg_tiles(18,1,1,16,Black);
                                set_bkg_tiles(17,2,1,14,Black);
                        }
                        TempX = PlayerX - 2;
                        TempY = PlayerY - 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(16,3,1,12,Light);
                                set_bkg_tiles(15,4,1,10,Light);
                                set_bkg_tiles(14,5,1,8,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(16,3,1,12,Dark);
                                set_bkg_tiles(15,4,1,10,Dark);
                                set_bkg_tiles(14,5,1,8,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(16,3,1,12,Black);
                                set_bkg_tiles(15,4,1,10,Black);
                                set_bkg_tiles(14,5,1,8,Black);
                        }
                        TempX = PlayerX - 3;
                        TempY = PlayerY - 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(13,6,1,6,Light);
                                set_bkg_tiles(12,7,1,4,Light);
                                set_bkg_tiles(11,8,1,2,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(13,6,1,6,Dark);
                                set_bkg_tiles(12,7,1,4,Dark);
                                set_bkg_tiles(11,8,1,2,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(13,6,1,6,Black);
                                set_bkg_tiles(12,7,1,4,Black);
                                set_bkg_tiles(11,8,1,2,Black);
                        }
                        TempX = PlayerX - 3;
                        TempY = PlayerY;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Black);
                                }
                        }
                        TempX = PlayerX - 2;
                        TempY = PlayerY;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Black);
                                }
                        }
                        TempX = PlayerX - 1;
                        TempY = PlayerY;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Black);
                                }
                        }
                        break;

                case 3: TempX = PlayerX + 1;
                        TempY = PlayerY - 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(0,0,1,18,Light);
                                set_bkg_tiles(1,1,1,16,Light);
                                set_bkg_tiles(2,2,1,14,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(0,0,1,18,Dark);
                                set_bkg_tiles(1,1,1,16,Dark);
                                set_bkg_tiles(2,2,1,14,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(0,0,1,18,Black);
                                set_bkg_tiles(1,1,1,16,Black);
                                set_bkg_tiles(2,2,1,14,Black);
                        }
                        TempX = PlayerX + 2;
                        TempY = PlayerY - 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(3,3,1,12,Light);
                                set_bkg_tiles(4,4,1,10,Light);
                                set_bkg_tiles(5,5,1,8,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(3,3,1,12,Dark);
                                set_bkg_tiles(4,4,1,10,Dark);
                                set_bkg_tiles(5,5,1,8,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(3,3,1,12,Black);
                                set_bkg_tiles(4,4,1,10,Black);
                                set_bkg_tiles(5,5,1,8,Black);
                        }
                        TempX = PlayerX + 3;
                        TempY = PlayerY - 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(6,6,1,6,Light);
                                set_bkg_tiles(7,7,1,4,Light);
                                set_bkg_tiles(8,8,1,2,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(6,6,1,6,Dark);
                                set_bkg_tiles(7,7,1,4,Dark);
                                set_bkg_tiles(8,8,1,2,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(6,6,1,6,Black);
                                set_bkg_tiles(7,7,1,4,Black);
                                set_bkg_tiles(8,8,1,2,Black);
                        }
                        TempX = PlayerX + 1;
                        TempY = PlayerY + 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(19,0,1,18,Light);
                                set_bkg_tiles(18,1,1,16,Light);
                                set_bkg_tiles(17,2,1,14,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(19,0,1,18,Dark);
                                set_bkg_tiles(18,1,1,16,Dark);
                                set_bkg_tiles(17,2,1,14,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(19,0,1,18,Black);
                                set_bkg_tiles(18,1,1,16,Black);
                                set_bkg_tiles(17,2,1,14,Black);
                        }
                        TempX = PlayerX + 2;
                        TempY = PlayerY + 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(16,3,1,12,Light);
                                set_bkg_tiles(15,4,1,10,Light);
                                set_bkg_tiles(14,5,1,8,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(16,3,1,12,Dark);
                                set_bkg_tiles(15,4,1,10,Dark);
                                set_bkg_tiles(14,5,1,8,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(16,3,1,12,Black);
                                set_bkg_tiles(15,4,1,10,Black);
                                set_bkg_tiles(14,5,1,8,Black);
                        }
                        TempX = PlayerX + 3;
                        TempY = PlayerY + 1;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                set_bkg_tiles(13,6,1,6,Light);
                                set_bkg_tiles(12,7,1,4,Light);
                                set_bkg_tiles(11,8,1,2,Light);
                        }
                        if(Map[TempA] == 2) {
                                set_bkg_tiles(13,6,1,6,Dark);
                                set_bkg_tiles(12,7,1,4,Dark);
                                set_bkg_tiles(11,8,1,2,Dark);
                        }
                        if(Map[TempA] == 3) {
                                set_bkg_tiles(13,6,1,6,Black);
                                set_bkg_tiles(12,7,1,4,Black);
                                set_bkg_tiles(11,8,1,2,Black);
                        }
                        TempX = PlayerX + 3;
                        TempY = PlayerY;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=6;FillX!=13;FillX++) {
                                        set_bkg_tiles(FillX,6,1,6,Black);
                                }
                        }
                        TempX = PlayerX + 2;
                        TempY = PlayerY;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=3;FillX!=17;FillX++) {
                                        set_bkg_tiles(FillX,3,1,12,Black);
                                }
                        }
                        TempX = PlayerX + 1;
                        TempY = PlayerY;
                        TempA = (TempY * 20) + TempX;
                        if(Map[TempA] == 1) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Light);
                                }
                        }
                        if(Map[TempA] == 2) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Dark);
                                }
                        }
                        if(Map[TempA] == 3) {
                                for(FillX=0;FillX!=20;FillX++) {
                                        set_bkg_tiles(FillX,0,1,18,Black);
                                }
                        }
                        break;


        }

}

// sprites are used soley to tell which direction the player is facing
// updating makes sure that the text being displayed is truly the
// direction the player is facing
void Update_Sprites()
{
        switch(PlayerZ) {
                        // north
                case 0: set_sprite_tile(0,14);
                        set_sprite_tile(1,15);
                        set_sprite_tile(2,18);
                        set_sprite_tile(3,20);
                        set_sprite_tile(4,8);
                        break;
                        // south
                case 1: set_sprite_tile(0,19);
                        set_sprite_tile(1,15);
                        set_sprite_tile(2,21);
                        set_sprite_tile(3,20);
                        set_sprite_tile(4,8);
                        break;
                        // west
                case 2: set_sprite_tile(0,23);
                        set_sprite_tile(1,5);
                        set_sprite_tile(2,19);
                        set_sprite_tile(3,20);
                        set_sprite_tile(4,0);
                        break;
                        // east
                case 3: set_sprite_tile(0,5);
                        set_sprite_tile(1,1);
                        set_sprite_tile(2,19);
                        set_sprite_tile(3,20);
                        set_sprite_tile(4,0);
                        break;
        }
}

// this moves the sprites to their initial locations as well as loads
// the alphabet tiles into sprite ram, sets the sprites to 8x8 mode,
// and makes them visible
void Init_Sprites()
{
        // sets the gbc palette
        set_sprite_palette(0,1,&Sprite_Palette);
        // load the data
        set_sprite_data(0,30,Alphabet_Tiles);
        // 8x8 pixel mode
        SPRITES_8x8;
        // show the sprites
        SHOW_SPRITES;
        // move the sprites to their locations in the upper left corner
        move_sprite(0,12,20);
        move_sprite(1,20,20);
        move_sprite(2,28,20);
        move_sprite(3,36,20);
        move_sprite(4,44,20);
}

