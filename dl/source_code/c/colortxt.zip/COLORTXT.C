// Color Text with GBDK
// A quick demonostration ROM
// Written by Jason
// http://www.tripmode.com/gbdev/
#include <gb.h>
#include "colors.h"

UWORD palette[] = {
black,black,black,red,          // palette 0
black,black,black,green,        // palette 1
black,black,black,blue,         // palette 2
};

unsigned char palettemap[] = {  // designate which palette to use
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
};

main()
{
        if(_cpu == CGB_TYPE) {          // if it is a gbc
                set_bkg_palette(0,3,&palette[0]);       // load the palette
                VBK_REG = 1;    // set to vram bank 1
                set_bkg_tiles(0,0,20,3,palettemap);     // set the palette map
                VBK_REG = 0;    // set to vram bank 0
                printf(" This is a gameboy\n color demonstration of colored text.");
        }
        else printf(" This gameboy does\n not support gameboy color palettes.");

        waitpad(J_START);       // wait for start to be pressed

        reset();        // rather than crash the gb
        return(0);      // return value 0, as it should have been error-free
}


