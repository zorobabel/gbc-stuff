// Com.C
// Written by Jason
// drunk-ass@beer.com
//
// Simple little program to tell if the GBC is receiving information from the
// communications port. Press A or B to send information through the port.
#include <gb.h>
#include <colors.h>

UWORD palettea[] = {
red,red,red,red,
};

UWORD paletteb[] = {
green,green,green,green,
};

UWORD palettec[] = {
black,darkgray,lightgray,white,
};

main()
{
	BYTE x, y;

	x = 0;

	// Show the background
	SHOW_BKG;		

	// Turn the display on		
	DISPLAY_ON;				

	// loop
	while(x == 0) {		
		// receive byte from com port
		receive_byte();
		// Set the value to be sent to 0x0A (10)
		_io_out = 0x0A;
		// Check the joypad. If a or b is pressed, send a byte through the com port
		if((joypad() & J_A) || (joypad() & J_B)) send_byte();
		// delay 10ms
		delay(10);
		// check to see if a signal was received
		if(_io_in != 0x00) {
			// decrease the received value counter
			_io_in--;
			// set the background counter to red
			set_bkg_palette(0,2,&palettea[0]);
		}
		// if the input counter is clear
		if(_io_in == 0x00) {
			// set the background green
			set_bkg_palette(0,2,&paletteb[0]);
		}
	}

	// no errors
	return(0);
}
