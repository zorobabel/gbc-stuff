#include <gb.h>
#include <stdlib.h>
#include <rand.h>

#include "ngfont.c"	//********Font file********
#include "jm002.c"	//********JetMan/Enemy tiles********
#include "jb002.c"	//********Background platforms********

UWORD x,y;
UWORD PlayerX,PlayerY,Score;
BYTE PlayerThrust;
UBYTE PlayerAirborne,PlayerDirection;
UBYTE PlayerWalkAnim[4], PlayerAnimCount;
UBYTE PlayerRapidFire;

WORD LaserX[2],LaserY[2],LaserDir[2],LaserLife[2];
UBYTE joystat;

WORD BadX[4],BadY[4];
BYTE BadAnimdDir[4],BadVertDir[4],BadAnim[4];

unsigned char txt_title[]="JETPAC";
unsigned char txt_score[]="SCORE:";	
unsigned char txt_ver[]="BETA V0.04";
unsigned char blank[]={0}, FloorLeft[]={1},FloorMid[]={2},FloorRight[]={3};

fixed seed;

//******** Title Screen *******************************************************
void Splash() {
	unsigned char txt_pushit[]="PUSH b IT!";
	unsigned char txt_dont[]="          ";
	
	BGP_REG = OBP0_REG = OBP1_REG = 27;
	SPRITES_8x8;
	
	set_bkg_data(0,5,BadAnimckground);
	set_bkg_data(33,66,Font);
	SHOW_BKG;
	
	for(x=0;x!=21;x++)
		for(y=0;y!=21;y++)
			set_bkg_tiles(x,y,1,1,blank);
	y=0;
	for(x=0;x!=1;){
		joystat=joypad();
		if (y<1000) {
			set_bkg_tiles(4,7,10,1,txt_pushit);
		}
		else {
			set_bkg_tiles(4,7,10,1,txt_dont);
		}
		y++;
		if (y==1500) y=0;
		if(joystat&J_START) x=1;
		if(joystat&J_A) x=1;
		if(joystat&J_B) x=1;
	}
	
}

void Initialise() {
	//********* Load Tiles and set sprites ************************************
	set_bkg_tiles(0,0,6,1,txt_title);
	set_sprite_data(0,30,Jetman);
	set_sprite_tile(0,0); set_sprite_tile(1,1);
	set_sprite_tile(2,9); set_sprite_tile(3,9);
	set_sprite_tile(4,9); set_sprite_tile(5,9);
	
	//********* Set starting variables ****************************************
	PlayerX=72; PlayerY=120; PlayerDirection=1;
	PlayerThrust=2; PlayerAirborne=1;
	PlayerWalkAnim[0]=0; PlayerWalkAnim[1]=2;
	PlayerWalkAnim[2]=4; PlayerWalkAnim[3]=2;
	PlayerAnimCount=0;
	Score=0;
	LaserX[0]=0; LaserY[0]=200; LaserLife[0]=0;
	LaserX[1]=0; LaserY[1]=200; LaserLife[1]=0;
	PlayerRapidFire=1;
	
	for(x=0;x!=4;x++) {
		BadX[x]=0;BadY[x]=0;
		BadAnimdDir[x]=0; BadVertDir[x]=0; BadAnim[x]=-100;
	}

}


//******** Draw background platforms ******************************************
void DrawBkg() {
	for(x=0;x!=21;x++)
		for(y=0;y!=21;y++)
			set_bkg_tiles(x,y,1,1,blank);
	
	set_bkg_tiles(0,0,6,1,txt_title);
	set_bkg_tiles(0,1,10,1,txt_ver);
	set_bkg_tiles(8,0,6,1,txt_score);

	set_bkg_tiles(0,17,1,1,FloorLeft);
	for(x=1;x!=19;x++) set_bkg_tiles(x,17,1,1,FloorMid);
	set_bkg_tiles(19,17,1,1,FloorRight);

	set_bkg_tiles(2,8,1,1,FloorLeft);
	for(x=3;x!=6;x++) set_bkg_tiles(x,8,1,1,FloorMid);
	set_bkg_tiles(6,8,1,1,FloorRight);

	set_bkg_tiles(9,11,1,1,FloorLeft);
	set_bkg_tiles(10,11,1,1,FloorMid);
	set_bkg_tiles(11,11,1,1,FloorRight);

	set_bkg_tiles(14,5,1,1,FloorLeft);
	for(x=15;x!=18;x++) set_bkg_tiles(x,5,1,1,FloorMid);
	set_bkg_tiles(18,5,1,1,FloorRight);
}

//********* Display Score - convert from WORD to CHARs ************************
void show_score( UWORD s ) {
	UWORD m;
	UBYTE i, n, f;
	unsigned char score[6];

	f=0; m=10000;
	for( i=0; i!=5; i++ ) {
		n=s/m; s=s%m; m=m/10;
		f=1;
		score[i]=0x30+n;
	}
	score[5]=0x30;  
	set_bkg_tiles(14,0,6,1,score);
}


void RefreshSprites()
{
	move_sprite(0,PlayerX,PlayerY); move_sprite(1,PlayerX,PlayerY+8); 
	move_sprite(2,LaserX[0],LaserY[0]); move_sprite(3,LaserX[0]+8,LaserY[0]); 
	move_sprite(4,LaserX[1],LaserY[1]); move_sprite(5,LaserX[1]+8,LaserY[1]);
	for(x=0;x!=4;x++) {
		if (BadAnimdDir[x]==0) {
			move_sprite(6+x,BadX[x],BadY[x]);
			move_sprite(10+x,BadX[x],BadY[x]+8);
			move_sprite(14+x,BadX[x]+8,BadY[x]);
			move_sprite(18+x,BadX[x]+8,BadY[x]+8);
		}
		if (BadAnimdDir[x]==1) {
			move_sprite(14+x,BadX[x],BadY[x]);
			move_sprite(18+x,BadX[x],BadY[x]+8);
			move_sprite(6+x,BadX[x]+8,BadY[x]);
			move_sprite(10+x,BadX[x]+8,BadY[x]+8);
		}
	}
	delay(10); 
}



void main()
{
	DISPLAY_ON;
		
	seed.b.l=DIV_REG;
	Splash();
	seed.b.h=DIV_REG;
	initarand(seed.w);
	Initialise();
	DrawBadAnimckGround();
			
	SHOW_SPRITES;	
	
	while(1){

		show_score(Score);
		joystat=joypad();
		
		//******** Player Logic ***********************************************
		if (PlayerDirection<2) {
			if(joystat&J_LEFT) {
				PlayerAnimCount=PlayerAnimCount+1;
				if(PlayerDirection==1){
					set_sprite_prop(0,S_FLIPX); set_sprite_prop(1,S_FLIPX);
					PlayerDirection=0; PlayerAnimCount=0;
				} else {
					PlayerX--;
					if (PlayerX<4) PlayerX=164;
					if (PlayerAirborne==1) PlayerX--;
				}
				if ((PlayerX>16)&&(PlayerX<64)&&(PlayerY>64)&&(PlayerY<88)) PlayerX=64;
				if ((PlayerX>72)&&(PlayerX<104)&&(PlayerY>88)&&(PlayerY<112)) PlayerX=104;
				if ((PlayerX>112)&&(PlayerX<160)&&(PlayerY>40)&&(PlayerY<64)) PlayerX=160;
			}
		
			if(joystat&J_RIGHT) {
				PlayerAnimCount=PlayerAnimCount+1;
				if(PlayerDirection==0){
					set_sprite_prop(0,!S_FLIPX); set_sprite_prop(1,!S_FLIPX);
					PlayerDirection=1; PlayerAnimCount=0;
				} else {
					PlayerX=PlayerX+1;
					if (PlayerX>164) PlayerX=4;
					if(PlayerAirborne==1) PlayerX++;
				}
				if ((PlayerX>16)&&(PlayerX<64)&&(PlayerY>64)&&(PlayerY<88)) PlayerX=16;
				if ((PlayerX>72)&&(PlayerX<104)&&(PlayerY>88)&&(PlayerY<112)) PlayerX=72;
				if ((PlayerX>112)&&(PlayerX<160)&&(PlayerY>40)&&(PlayerY<64)) PlayerX=112;
			}
		
			PlayerAirborne=1;
			if(joystat&J_A) PlayerThrust=PlayerThrust-1; else PlayerThrust=PlayerThrust+1;
			
			PlayerRapidFire--; if (PlayerRapidFire==0) PlayerRapidFire=1;
			if((joystat&J_B)&&(PlayerRapidFire==1)){
				PlayerRapidFire=5;
				if(LaserLife[0]==0) {
					LaserLife[0]=9; LaserY[0]=PlayerY; 
					if (PlayerDirection==0) {
						LaserX[0]=PlayerX; LaserDir[0]=-16;
					} else {
						LaserX[0]=PlayerX-8; LaserDir[0]=16;
					}
				} else if(LaserLife[1]==0) {
					LaserLife[1]=9; LaserY[1]=PlayerY;
					if (PlayerDirection==0) {
						LaserX[1]=PlayerX; LaserDir[1]=-16;
					} else {
						LaserX[1]=PlayerX-8; LaserDir[1]=16;
					}
				}		
			}
			
			if (PlayerThrust<-3) PlayerThrust=-3;
			if (PlayerThrust>2) PlayerThrust=2;
			
			PlayerY=PlayerY+PlayerThrust;
		
			if(PlayerThrust<0) {
				if ((PlayerX>16)&&(PlayerX<64)&&(PlayerY>80)&&(PlayerY<88)) PlayerY=88;
				if ((PlayerX>72)&&(PlayerX<104)&&(PlayerY>104)&&(PlayerY<112)) PlayerY=112;
				if ((PlayerX>112)&&(PlayerX<160)&&(PlayerY>56)&&(PlayerY<64)) PlayerY=64;
			}
		
			if(PlayerY<32) PlayerY=32; /* Stop man flying too high */
				
			if (PlayerY>136) {
				PlayerY=136; if (PlayerThrust==2) PlayerAirborne=0;
			}
			if((PlayerX> 16)&&(PlayerX< 64)&&(PlayerY>64)&&(PlayerY<72)) {
				PlayerY= 64; if (PlayerThrust==2) PlayerAirborne=0;
			}
			if((PlayerX> 72)&&(PlayerX<104)&&(PlayerY>88)&&(PlayerY<96)) {
				PlayerY= 88; if (PlayerThrust==2) PlayerAirborne=0;
			}
			if((PlayerX>112)&&(PlayerX<160)&&(PlayerY>40)&&(PlayerY<48)) {
				PlayerY= 40; if (PlayerThrust==2) PlayerAirborne=0;
			}
		
			if ((PlayerAnimCount+PlayerAirborne)>3) PlayerAnimCount=0;
			if(PlayerAirborne==0){
				set_sprite_tile(0,PlayerWalkAnim[PlayerAnimCount]);
				set_sprite_tile(1,PlayerWalkAnim[PlayerAnimCount]+1);
			} else {
				set_sprite_tile(0,0);set_sprite_tile(1,6+PlayerAnimCount);
			}
		} else {
			if (PlayerDirection<6) {
				set_sprite_tile(0,10);
				set_sprite_tile(1,10);
			} else {
				set_sprite_tile(0,11);
				set_sprite_tile(1,11);
			}
			PlayerDirection++;
			if (PlayerDirection==9) {
				PlayerX=72; PlayerY=120;
				set_sprite_prop(0,!S_FLIPX); set_sprite_prop(1,!S_FLIPX);
				PlayerDirection=1; PlayerAnimCount=0;
				PlayerThrust=2; PlayerAirborne=1;
				for(x=0;x!=4;x++) {
					BadX[x]=0;BadY[x]=0;
					BadAnimdDir[x]=0; BadVertDir[x]=0;
					BadAnim[x]=-50;
				}
			}
		}
		
		
		//******** Laser Logic ************************************************
		if (LaserLife[0]!=0) {
			LaserLife[0]--;
			LaserX[0]=LaserX[0]+LaserDir[0];
			if (LaserX[0]<-8) LaserX[0]=168;
			if (LaserX[0]>168) LaserX[0]=-8;
			if ((LaserX[0]>16 )&&(LaserX[0]<56 )&&(LaserY[0]>73)&&(LaserY[0]<85 )) LaserLife[0]=0;
			if ((LaserX[0]>72 )&&(LaserX[0]<96 )&&(LaserY[0]>97)&&(LaserY[0]<109)) LaserLife[0]=0;
			if ((LaserX[0]>112)&&(LaserX[0]<154)&&(LaserY[0]>49)&&(LaserY[0]<61 )) LaserLife[0]=0;
			if (LaserLife[0]==0) LaserY[0]=200;
		}
		if (LaserLife[1]!=0) {
			LaserLife[1]--;
			LaserX[1]=LaserX[1]+LaserDir[1];
			if (LaserX[1]<-8) LaserX[1]=168;
			if (LaserX[1]>168) LaserX[1]=-8;
			if ((LaserX[1]>16 )&&(LaserX[1]<56 )&&(LaserY[1]>73)&&(LaserY[1]<85 )) LaserLife[1]=0;
			if ((LaserX[1]>72 )&&(LaserX[1]<96 )&&(LaserY[1]>97)&&(LaserY[1]<109)) LaserLife[1]=0;
			if ((LaserX[1]>112)&&(LaserX[1]<154)&&(LaserY[1]>49)&&(LaserY[1]<61 )) LaserLife[1]=0;
			if (LaserLife[1]==0) LaserY[1]=200;
		}
		

		//******** Enemy Logice ***********************************************
		for(x=0;x!=4;x++) {
			if (BadAnimdDir[x]<2) {
				if (BadAnim[x]<0) BadAnim[x]++;
				else if (BadY[x]==0) {
					BadY[x]=(arand()%20)+10;
					BadY[x]=BadY[x]*4;
					BadAnimdDir[x]=arand()%2;
					BadVertDir[x]=arand()%2;				
					if (BadAnimdDir[x]==0) {
						BadX[x]=168;
						set_sprite_prop(6+x,!S_FLIPX);
						set_sprite_prop(10+x,!S_FLIPX);
						set_sprite_prop(14+x,!S_FLIPX);
						set_sprite_prop(18+x,!S_FLIPX);
					}
					if (BadAnimdDir[x]==1) {
						BadX[x]=-8;
						set_sprite_prop(6+x,S_FLIPX);
						set_sprite_prop(10+x,S_FLIPX);
						set_sprite_prop(14+x,S_FLIPX);
						set_sprite_prop(18+x,S_FLIPX);
					}
				}
				if (BadAnimdDir[x]==0) {
					BadX[x]=BadX[x]-2;
				}
				if (BadAnimdDir[x]==1) {
					BadX[x]=BadX[x]+2;
				}
				if (BadX[x]<-8) BadX[x]=168;
				if (BadX[x]>168) BadX[x]=-8;
	
	
				if (BadVertDir[x]==1) {
					BadY[x]=BadY[x]+1;
	
					if (BadY[x]>138) BadAnimdDir[x]=2;
					if((BadX[x]> 16)&&(BadX[x]< 56)&&(BadY[x]>66)&&(BadY[x]<72)) BadAnimdDir[x]=2;
					if((BadX[x]> 72)&&(BadX[x]< 96)&&(BadY[x]>90)&&(BadY[x]<96)) BadAnimdDir[x]=2;
					if((BadX[x]>112)&&(BadX[x]<154)&&(BadY[x]>42)&&(BadY[x]<48)) BadAnimdDir[x]=2;
				}

				if ((BadX[x]>16 )&&(BadX[x]<56 )&&(BadY[x]>64)&&(BadY[x]< 88)) BadAnimdDir[x]=2;
				if ((BadX[x]>72 )&&(BadX[x]<96 )&&(BadY[x]>88)&&(BadY[x]<112)) BadAnimdDir[x]=2;
				if ((BadX[x]>112)&&(BadX[x]<154)&&(BadY[x]>40)&&(BadY[x]< 64)) BadAnimdDir[x]=2;
	
				if ((BadX[x]>LaserX[0]-16)&&(BadX[x]<LaserX[0]+16)&&(BadY[x]>LaserY[0]-16)&&(BadY[x]<LaserY[0]+8)) {
					BadAnimdDir[x]=2;
					Score=Score+5;
				} else 
				if ((BadX[x]>LaserX[1]-16)&&(BadX[x]<LaserX[1]+16)&&(BadY[x]>LaserY[1]-16)&&(BadY[x]<LaserY[1]+8)) {
					BadAnimdDir[x]=2;
					Score=Score+5;
				}

				BadAnim[x]++;
				if(BadAnim[x]==4) BadAnim[x]=0;
				if(BadAnim[x]<2) {
					set_sprite_tile(6+x,20);
					set_sprite_tile(10+x,21);
					set_sprite_tile(14+x,22);
					set_sprite_tile(18+x,23);
				} else {
					set_sprite_tile(6+x,24);
					set_sprite_tile(10+x,25);
					set_sprite_tile(14+x,26);
					set_sprite_tile(18+x,27);
				}
				if ((BadX[x]>PlayerX-14)&&(BadX[x]<PlayerX+6)&&(BadY[x]>PlayerY-14)&&(BadY[x]<PlayerY+14)) {
					PlayerDirection=2;
				} 
			} else {
				if  (BadAnimdDir[x]<5) {
					set_sprite_tile(6+x,12);
					set_sprite_tile(10+x,13);
					set_sprite_tile(14+x,14);
					set_sprite_tile(18+x,15);
				} else {
					set_sprite_tile(6+x,16);
					set_sprite_tile(10+x,17);
					set_sprite_tile(14+x,18);
					set_sprite_tile(18+x,19);
				}
				BadAnimdDir[x]++;
				if (BadAnimdDir[x]==7) {
					BadAnimdDir[x]=0; BadVertDir[x]=0; BadY[x]=0; BadX[x]=0;
					BadAnim[x]=-50;
				}
			}
		}

		
		RefreshSprites();
	}
}

