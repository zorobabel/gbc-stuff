// Step-by-step example of how to use the output of GBTK
// to create a gbc rom with the image in it.
// The original picture was Jason with a girl and a condom. =)
// Written in about 5 minutes by Jason (drunk-ass@beer.com)
// http://www.gbdev.org/news/                   12/4/99

#include <gb.h>                                 // gb defines
#include <colors.h>                             // color defines
#include "gbtk.h"                               // gbtk output file

UWORD pal[] = {                                 // picture palette.
white,lightgray,darkgray,black,                 // - change to make picture
};                                              //   colorized

main()                                          // main code
{
        DISPLAY_OFF;                            // turn the display off
        set_bkg_data(0,236,gbtk_tiledata);      // set the background data
                                                // gbdk_tiledata is defined
                                                // in gbtk.h. Since the
                                                // output file was named
                                                // gbtk, gbtk named the tile
                                                // data and tile map
                                                // gbtk_tiledata and
                                                // gbtk_tilemap respectively.
        set_bkg_tiles(3,0,13,18,gbtk_tilemap);  // set the background tiles
        set_bkg_palette(0,2,&pal[0]);           // set the background palette
        SHOW_BKG;                               // show the background
        DISPLAY_ON;                             // turn the display on
        while(!0)                               // loop
           ;
        return(0);                              // return 0
}
