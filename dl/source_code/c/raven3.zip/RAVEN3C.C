/*
Seperate routines are called to access the data loacted in 
bank 3 since GBDK doesn't want to call data from other
banks.
*/
#include <gb.h>
#include "9.dat"
#include "10.dat"
#include "11.dat"

void load9(void)
{
    set_bkg_data(0,234,tile9);		// load frame 9 data
}

void load10(void)
{
    set_bkg_data(0,234,tile10);		// load frame 10 data
}

void load11(void)
{
    set_bkg_data(0,234,tile11);		// load frame 11 data
}



