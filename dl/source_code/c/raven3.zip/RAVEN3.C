#include <gb.h>
#include "pics.map"
#include "1.dat"
#include "2.dat"
#include "3.dat"
#include "4.dat"

void vblint();		// VBlank Interrupt Routine
void load5();		// Routine to load frame 5
void load6();		// Routine to load frame 6
void load7();		// Routine to load frame 7
void load8();		// Routine to load frame 8
void load9();		// Routine to load frame 9
void load10();		// Routine to load frame 10
void load11();		// Routine to load frame 11

unsigned int frame;	// frane number
unsigned int count;	// which frame you're on

main()
{
    frame = 2;		// initial values
    count = 0;		// initial values

    disable_interrupts();	// disable the interrupts
    add_vbl(vblint);		// add vblint as routine to call during vblanks

    set_bkg_tiles(0,0,18,13,tilemap);	// set frame 1's background tiles
    SHOW_BKG;				// show the background

    set_bkg_data(0,234,tile1);		// load frame 1
    enable_interrupts();		// enable the interrupts

    while(!0) { 			// infinite loop
    }
    return(0);				// return 0
}

void vblint(void)
{
  disable_interrupts();			// disable interrupts
  count++;				// increase vblank count

  if(count == 5) {			// on 5, do...
    if(frame == 1) set_bkg_data(0,234,tile1);	// load frame 1
    if(frame == 2) set_bkg_data(0,234,tile2);	// load frame 2
    if(frame == 3) set_bkg_data(0,234,tile3);	// load frame 3
    if(frame == 4) set_bkg_data(0,234,tile4);	// load frame 4
    if(frame == 5) { 
	SWITCH_ROM_MBC1(2);	// switch to ROM bank 2
	load5();	// load frame 5
    }
    if(frame == 6) { 
	SWITCH_ROM_MBC1(2);	// switch to ROM bank 2
	load6();	// load frame 6
    }
    if(frame == 7) { 
	SWITCH_ROM_MBC1(2);	// switch to ROM bank 2
	load7();	// load frame 7
    }
    if(frame == 8) { 
	SWITCH_ROM_MBC1(2);	// switch to ROM bank 2
	load8();	// load frame 8
    }
    if(frame == 9) { 
	SWITCH_ROM_MBC1(3);	// switch to ROM bank 3
	load9();	// load frame 9
    }
    if(frame == 10) { 
	SWITCH_ROM_MBC1(3);	// switch to ROM bank 3
	load10();	// load frame 10
    }
    if(frame == 11) { 
	SWITCH_ROM_MBC1(3);	// switch to ROM bank 3
	load11();	// load frame 11
    }
    count=0;		// reset counter
    frame++;		// increas frame #
    if(frame == 12) frame = 0;	// reset frame counter
  }
  enable_interrupts();		// enable interrupts
}
