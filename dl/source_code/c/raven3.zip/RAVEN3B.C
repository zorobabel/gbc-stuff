/*
Uses Bank 2 since using Bank 1 overwrites data
*/
#include <gb.h>
#include "5.dat"
#include "6.dat"
#include "7.dat"
#include "8.dat"

void load5(void)
{
    set_bkg_data(0,234,tile5);		// Load frame 5
}

void load6(void)
{
    set_bkg_data(0,234,tile6);		// Load frame 6
}

void load7(void)
{
    set_bkg_data(0,234,tile7);		// Load frame 7
}

void load8(void)
{
    set_bkg_data(0,234,tile8);		// Load frame 8
}


