/* 
Jason presents
Sega's 
Hang-On
(c) 1985, 1998

Game created for 3 reasons
1) Hang-On kicks ass =)
2) Dirt/Street bikes kick ass
and 3) to demonstrate practicle uses for my DirectY Graphics Programming Add-On library
*/

#include <gb.h>          /* main gb shit */
#include <directy.h>    /* add-on graphics library */
#include <rand.h>        /* random number calls */

fixed seed;

unsigned char Graphics[] =
{
  0x00,0x01,0x01,0x02,0x03,0x00,0x02,0x01,
  0x00,0x07,0x04,0x1B,0x1E,0x01,0x3F,0x00,
  0x00,0x80,0x80,0x40,0xC0,0x00,0x40,0x80,
  0x00,0xE0,0x20,0xD8,0x78,0x80,0xFC,0x00,
  0x37,0x00,0x33,0x00,0x07,0x08,0x0E,0x11,
  0x18,0x27,0x07,0x19,0x1E,0x0A,0x1F,0x09,
  0xEC,0x00,0xCC,0x00,0xE0,0x10,0x70,0x88,
  0x18,0xE4,0xE0,0x98,0x78,0x50,0xF8,0x90,
  0x18,0x07,0x0A,0x05,0x0B,0x04,0x02,0x05,
  0x02,0x01,0x03,0x01,0x01,0x01,0x01,0x01,
  0x18,0xE0,0x50,0xA0,0xD0,0x20,0x40,0xA0,
  0x40,0x80,0xC0,0x80,0x80,0x80,0x80,0x80,
  0x00,0x00,0x18,0x00,0x00,0x18,0x18,0x18,
  0x00,0x18,0x18,0x00,0x18,0x00,0x18,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

main()
{
  int playing;    /* integer that determines if the game is playing */
  unsigned int roadx;    /* x-axis of the road */
  unsigned int oldx;    /* old x-axis */
  unsigned int speed;  /* speed of bike in mph */
  unsigned int gear;    /* gear of bike, determines how fast the bike looks like it's going */
  unsigned int posty;    /* y-axis of the posts */
  unsigned int randnum;    /* random number variable */
  int bikedir;      /* other bike's direction */
  unsigned int bikex;      /* bike's x-axis */
  unsigned int bikey;      /* bike's y-axis */
  int roaddir;    /* direction of the road */
  unsigned int counter;    /* counter */
      
  cls();    /* clear the screen */
  gotoxy(1,1);  /* goto 1,1 on the screen */
  printf("Game written by\n Jason.\n\n Original game \n %c Sega 1985.", 189);    /* print legalities */
  delay(500);    /* wait 1/2 second */
  cls();    /* clear the screen */
  seed.b.l = DIV_REG;
  bevel(2,2,155,130);    /* Bevel */
  filledrectangle(10,5,20,45,3);      /* H */
  filledrectangle(20,17,25,22,3);    /* 10,5 to 35,45 */
  filledrectangle(25,5,35,45,3);
  filledrectangle(40,10,50,45,3);    /* A */
  filledrectangle(50,5,60,10,3);    /* 40,5 to 70,45 */
  filledrectangle(50,17,60,22,3); 
  filledrectangle(60,10,70,45,3); 
  filledrectangle(75,5,85,45,3);    /* N */
  filledrectangle(85,12,90,22,3);  /* 75,5 to 105,45 */
  filledrectangle(90,22,95,32,3);
  filledrectangle(95,5,105,45,3);
  filledrectangle(110,15,120,35,3);     /* G */
  filledrectangle(120,5,140,15,3);    /* 110,5 to 145,45 */
  filledrectangle(120,35,140,45,3);
  filledrectangle(140,15,145,20,3);
  filledrectangle(140,30,145,35,3);
  filledrectangle(135,25,145,30,3);
  filledrectangle(30,60,40,85,3);      /* O */
  filledrectangle(40,50,60,60,3);      /* 50,50 to 70,95 */
  filledrectangle(40,85,60,95,3);
  filledrectangle(60,60,70,85,3);
  filledrectangle(75,50,85,95,3);    /* N */
  filledrectangle(85,57,90,67,3);  /* 75,50 to 105,95 */
  filledrectangle(90,67,95,77,3);
  filledrectangle(95,50,105,95,3);
  waitpad(J_A + J_B + J_START);    /* wait for a, b, or start */
  seed.b.h = DIV_REG;
  initarand(seed.w);
  filledrectangle(0,0,160,144,0);    /* clear the screen */
  
  SPRITES_8x8;      /* set sprite mode to 8x8 */
  set_sprite_data(0, 14, Graphics);   /* Set sprite data */
  set_sprite_tile(0,0);            
  set_sprite_tile(1,1);
  set_sprite_tile(2,2);
  set_sprite_tile(3,3);
  set_sprite_tile(4,4);            
  set_sprite_tile(5,5);
  set_sprite_tile(6,6);
  set_sprite_tile(7,6);
  set_sprite_tile(8,0);
  set_sprite_tile(9,1);
  set_sprite_tile(10,2);
  set_sprite_tile(11,3);
  set_sprite_tile(12,4);
  set_sprite_tile(13,5);
  move_sprite(0,80,122);
  move_sprite(1,88,122);
  move_sprite(2,80,130);
  move_sprite(3,88,130);
  move_sprite(4,80,138);
  move_sprite(5,88,138);
  SHOW_SPRITES;

  playing = 0;
  roadx = 50;
  posty = 80;
  bikedir = 0;
  roaddir = 0;
  counter = 0;
  speed = 0;
        
  filledrectangle(0,80,roadx,144,1);
  filledrectangle(roadx + 60,80,160,144,1);
  rectangle(0,80,160,81,1);
  rectangle(0,79,160,80,2);
  rectangle(0,78,160,79,3);
  waitpad(J_A);
      
  while(playing == 0) {
    randnum = arand();
    oldx = roadx;
    move_sprite(0,80,122);
    move_sprite(1,88,122);
    move_sprite(2,80,130);
    move_sprite(3,88,130);
    move_sprite(4,80,138);
    move_sprite(5,88,138);
    if(speed < 3) gear = 0;
    if((speed < 100) && (speed > 2)) gear = 1;
    if((speed > 100) && (speed < 200)) gear = 2;
    if(speed > 200) gear = 3;
    if((speed > 1) && (roaddir == 1)) {
      if(randnum > 200) roadx--; /* = roadx + 5; */
    }
    if((speed > 1) && (roaddir == 2)) {
      if(randnum > 200) roadx++; /* = roadx + 5;*/
    }
    if(joypad() & J_A) {
      if(speed != 255) speed = speed + 2;
      delay(2);
    }
    speed--;
    if(joypad() & J_B) {
      if(speed > 3) speed = speed - 3;
      delay(2);
    }
    if(joypad() & J_LEFT) {
      if(roadx < 100) roadx++;
      move_sprite(0,76,122);
      move_sprite(1,84,122);
      move_sprite(2,78,130);
      move_sprite(3,86,130);
      move_sprite(4,80,138);
      move_sprite(5,88,138);
    }
    if(joypad() & J_RIGHT) {
      if(roadx > 0) roadx--;
      move_sprite(0,84,122);
      move_sprite(1,92,122);
      move_sprite(2,82,130);
      move_sprite(3,90,130);
      move_sprite(4,80,138);
      move_sprite(5,88,138);
    }
    if(roadx != oldx) {
      rectangle(roadx - 1,82,roadx, 144, 1);
      rectangle(roadx,82,roadx + 1, 144, 0);
      rectangle(roadx + 59,82,roadx + 60, 144, 0);
      rectangle(roadx + 60,82,roadx + 61, 144, 1);
    }
    move_sprite(6,roadx + 6, posty);
    move_sprite(7,roadx + 64,posty);
    if((gear == 1) && (speed > 3)) posty++;
    if((gear == 2) && (speed > 3)) posty = posty + 2;
    if((gear == 3) && (speed > 3)) posty = posty + 3;
    if(posty > 160) posty = 80;
    if(oldx == roadx) delay(15);
    if((randnum < 50) && (bikedir == 0)) {
        randnum = arand();
        if(gear == 3) bikedir = 1;
        if(gear < 3) bikedir = 2;
        if(bikedir == 1) bikey = 80;
        if(bikedir == 2) bikey = 160;
        bikex = randnum / 4;
    }
    if(bikedir > 0) {
      move_sprite(8,bikex + roadx,bikey);
      move_sprite(9,bikex + roadx + 8,bikey);
      move_sprite(10,bikex + roadx,bikey + 8);
      move_sprite(11,bikex + roadx + 8,bikey + 8);
      move_sprite(12,bikex + roadx,bikey + 16);
      move_sprite(13,bikex + roadx + 8,bikey + 16);
    }
    if(bikedir == 1) {
      bikey++;
      if(bikey == 160) bikedir = 0;
    }
    if(bikedir == 2) {
      bikey--;
      if(bikey == 80) bikedir = 0;
    }
    if(speed > 1) {
      counter++;
      if(counter == 40) {
        counter = 0;
        randnum = arand();
        if(randnum < 100) roaddir = 2;
        if(randnum > 200) roaddir = 1;
        if((randnum > 100) && (randnum < 200)) roaddir = 0;
      }
    }
  }
}
