/* Pong */
/* Written by Jason */

#include <gb.h>

unsigned char Graphics[] =
{
  0x00,0x00,0x00,0x00,0x18,0x18,0x3C,0x34,
  0x3C,0x3C,0x18,0x18,0x00,0x00,0x00,0x00,
  0xF3,0x0F,0x79,0x03,0x3C,0x03,0x1E,0x01,
  0x0F,0x00,0x07,0x00,0x03,0x00,0x01,0x00,
  0x01,0x38,0x39,0x44,0x45,0xBA,0x09,0xC6,
  0x01,0x44,0x09,0x44,0x01,0x38,0x20,0x5F,
  0x60,0x9F,0x7D,0x82,0x01,0xFE,0x01,0x38,
  0x01,0x3C,0x03,0x00,0x06,0x01,0x0C,0x03,
  0xA0,0xC0,0xA0,0xC0,0xA0,0xC0,0xA0,0xC0,
  0xA0,0xC0,0xA0,0xC0,0xA0,0xC0,0xA0,0xC0,
  0xA6,0xC0,0xAF,0xD0,0xAF,0xD0,0xA6,0xC0,
  0xAF,0xC0,0xA1,0xDE,0xAF,0xC0,0xA7,0xC0,
  0xAF,0xC0,0xA0,0xC0,0xA0,0xC0,0xA0,0xC0,
  0xA0,0xC0,0xA0,0xC0,0xA0,0xC0,0xA0,0xC0,
  0x00,0x1F,0x00,0x7F,0x00,0xFF,0x00,0x43,
  0x12,0x41,0x12,0x40,0x00,0x40,0x20,0x41,
  0x00,0x00,0x00,0xC0,0x00,0xF0,0x00,0xE0,
  0x00,0xC0,0x00,0x80,0x00,0x80,0x00,0x80,
  0x14,0x43,0x22,0x01,0x54,0x2B,0xAA,0x14,
  0xD5,0x00,0x94,0x00,0x2A,0x14,0x14,0x2A,
  0x00,0x80,0x00,0x80,0x00,0x00,0x80,0x00,
  0x80,0x00,0x80,0x00,0x00,0x00,0x00,0x00,
  0x2A,0x00,0x4A,0x00,0x99,0x00,0xA5,0x42,
  0xC2,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x2A,0x00,0x2A,0x00,0x2A,0x00,0x2A,0x00,
  0x2A,0x14,0x3E,0x00,0x00,0x00,0x00,0x00,
  0x14,0x43,0x2A,0x00,0x41,0x94,0x2A,0x80,
  0x14,0x80,0x14,0xC1,0x2A,0x14,0x14,0x2A
};



main()
{
  unsigned int BallX, BallY, Paddle1Y, Paddle2Y, speed, comp, player;
  int BallDir;

  printf("\n\n    South Pong\n\n");          /* Opening Screen */
  printf(" Written by Jason\n\n");
  printf(" Written with GBDK\n\n");  
  printf(" Thanks to #GB-DEV\n and #GBDEV");
  waitpad(J_A + J_B + J_START);
  cls();
  
  BallX = 78;        /* Initial Values */
  BallY= 74;
  BallDir = 3;
  Paddle1Y = 70;
  Paddle2Y = 70;
  speed = 40;
  comp = 0;
  player = 0;
    
  SPRITES_8x8;      /* Initalize Sprites */
  set_sprite_data(0, 14, Graphics);   
  set_sprite_tile(0,0);            
  set_sprite_tile(1,1);
  set_sprite_tile(2,2);
  set_sprite_tile(3,3);
  set_sprite_tile(4,4);            
  set_sprite_tile(5,5);
  set_sprite_tile(6,6);

  set_sprite_tile(7,7);      /* Cheerleader 1 */
  set_sprite_tile(8,8);
  set_sprite_tile(9,9);
  set_sprite_tile(10,10);
  set_sprite_tile(11,11);
  set_sprite_tile(12,12);
  
  set_sprite_tile(13,7);      /* Cheerleader 2 */
  set_sprite_tile(14,8); 
  set_sprite_tile(15,9); 
  set_sprite_tile(16,10); 
  set_sprite_tile(17,11); 
  set_sprite_tile(18,12); 

  set_sprite_tile(19,7);      /* Cheerleader 3 */
  set_sprite_tile(20,8); 
  set_sprite_tile(21,9); 
  set_sprite_tile(22,10); 
  set_sprite_tile(23,11); 
  set_sprite_tile(24,12); 

  set_sprite_tile(25,13);
  set_sprite_tile(26,13);
  set_sprite_tile(27,13);
  
  move_sprite(0,78,74);
  move_sprite(1,14,Paddle1Y);
  move_sprite(2,14,Paddle1Y + 8);
  move_sprite(3,14,Paddle1Y + 16);
  move_sprite(4,150,Paddle2Y);
  move_sprite(5,150,Paddle2Y + 8);
  move_sprite(6,150,Paddle2Y + 16);
  SHOW_SPRITES;
  
  while(!0)        /* Main Game Engine is here */
  {
    if(comp == 250) {
      move_sprite(0,420,420);
      move_sprite(1,420,420);
      move_sprite(2,420,420);
      move_sprite(3,420,420);
      move_sprite(4,420,420);
      move_sprite(5,420,420);
      move_sprite(6,420,420);
      cls();
      gotoxy(3,0);
      printf("           \n");
      printf("                 \n");
      printf("              \n");
      printf("   GAME OVER");
      waitpad(J_A + J_B + J_START);
      reset();
    }
    if(player == 250) {      /* You win */
      move_sprite(0,420,420);
      move_sprite(1,420,420);
      move_sprite(2,420,420);
      move_sprite(3,420,420);
      move_sprite(4,420,420);
      move_sprite(5,420,420);
      move_sprite(6,420,420);
      gotoxy(3,0);
      printf("           \n");
      printf("                 \n");
      printf("              \n");
      printf("   You Win!");
      move_sprite(7,50,70);    /* Cheerleader 1 */
      move_sprite(8,58,70);
      move_sprite(25,50,78);
      move_sprite(10,58,78);
      move_sprite(11,50,86);
      move_sprite(13,80,70);    /* Cheerleader 2 */
      move_sprite(14,88,70);
      move_sprite(26,80,78);  
      move_sprite(16,88,78);
      move_sprite(17,80,86);
      move_sprite(19,110,70);    /* Cheerleader 3 */
      move_sprite(20,118,70);
      move_sprite(27,110,78);
      move_sprite(22,118,78);
      move_sprite(23,110,86);
      waitpad(J_A + J_B + J_START);
      reset();
    }
    if((player == 25)  || (player == 50) || (player == 75) || (player == 100) || (player == 125) || (player == 150) || (player == 175) || (player == 200) || (player == 225)) {        /* Welcome to intermission */
      move_sprite(0,420,420);
      move_sprite(1,420,420);
      move_sprite(2,420,420);
      move_sprite(3,420,420);
      move_sprite(4,420,420);
      move_sprite(5,420,420);
      move_sprite(6,420,420);
      gotoxy(3,0);
      printf("           \n");
      printf("                 \n");
      printf("              \n");
      printf("   Intermission");
      move_sprite(7,50,70);    /* Cheerleader 1 */
      move_sprite(8,58,70);
      move_sprite(9,50,78);
      move_sprite(10,58,78);
      move_sprite(11,50,86);
      move_sprite(13,80,70);    /* Cheerleader 2 */
      move_sprite(14,88,70);
      move_sprite(15,80,78);
      move_sprite(16,88,78);
      move_sprite(17,80,86);
      move_sprite(19,110,70);    /* Cheerleader 3 */
      move_sprite(20,118,70);
      move_sprite(21,110,78);
      move_sprite(22,118,78);
      move_sprite(23,110,86);
      delay(500);
      move_sprite(12,420,420);
      move_sprite(18,420,420);
      move_sprite(24,420,420);
      move_sprite(11,50,86);
      move_sprite(17,80,86);
      move_sprite(23,110,86);
      delay(500);
      move_sprite(11,420,420);
      move_sprite(17,420,420);
      move_sprite(23,420,420);
      move_sprite(12,50,86);
      move_sprite(18,80,86);
      move_sprite(24,110,86);
      delay(500);
      move_sprite(12,420,420);
      move_sprite(18,420,420);
      move_sprite(24,420,420);
      move_sprite(11,50,86);
      move_sprite(17,80,86);
      move_sprite(23,110,86);
      delay(500);
      move_sprite(11,420,420);
      move_sprite(17,420,420);
      move_sprite(23,420,420);
      move_sprite(12,50,86);
      move_sprite(18,80,86);
      move_sprite(24,110,86);
      delay(500);
      player++;
      waitpad(J_A + J_B + J_START);
      move_sprite(7,450,470);    /* Cheerleader 1 */
      move_sprite(8,458,470);
      move_sprite(9,450,478);
      move_sprite(10,458,478);
      move_sprite(11,450,486);
      move_sprite(12,450,486);
      move_sprite(13,480,470);    /* Cheerleader 2 */
      move_sprite(14,488,470);
      move_sprite(15,480,478);
      move_sprite(16,488,478);
      move_sprite(17,480,486);
      move_sprite(18,450,486);
      move_sprite(19,410,470);    /* Cheerleader 3 */
      move_sprite(20,418,470);
      move_sprite(21,410,478);
      move_sprite(22,418,478);
      move_sprite(23,410,486);
      move_sprite(24,450,486);
    }    
    if(joypad() == J_A) {
      if(Paddle1Y > 20) {
        Paddle1Y--;
        Paddle1Y--;
        Paddle1Y--;
        Paddle1Y--;
        Paddle1Y--;     
      }
    }
    if(joypad() == J_B) {
      if(Paddle1Y < 130) {
        Paddle1Y++;
        Paddle1Y++;
        Paddle1Y++;
        Paddle1Y++;
        Paddle1Y++;
      }      
    }
    if(joypad() == J_SELECT) {
      if(speed != 200) {
        speed++;
      }
    }
    if(joypad() == J_START) {
      if(speed != 10) {
        speed--;
      }
    }
    if(joypad() == J_UP) {      /* If up is pressed, move paddle up */
      if(Paddle1Y > 16) {
        Paddle1Y--;
        Paddle1Y--;
        Paddle1Y--;
       }
    }
    if(joypad() == J_DOWN) {      /* If down is pressed, move paddle down */
      if(Paddle1Y < 136) {
        Paddle1Y++;
        Paddle1Y++;
        Paddle1Y++;
       }
    }
    move_sprite(0,BallX,BallY);      /* ReDraw moved paddle */
    move_sprite(1,14,Paddle1Y);
    move_sprite(2,14,Paddle1Y + 8);
    move_sprite(3,14,Paddle1Y + 16);
    
    if(BallY < Paddle2Y) {      /* Move 2nd. Player Paddle */
      Paddle2Y--;
      Paddle2Y--;
    }  
    if(BallY > Paddle2Y) {
      Paddle2Y++;
      Paddle2Y++;
      Paddle2Y++;
    }  
    move_sprite(4,150,Paddle2Y);    /* Update Player 2 Paddle graphics */
    move_sprite(5,150,Paddle2Y + 8);
    move_sprite(6,150,Paddle2Y + 16);
    
/* Ball Direction Reference */
/* 1 - 2 */
/* 3 - 4 */
    
    /* Hard Part here */
    if(BallDir == 1) {      /* Check the ball and make it bounce */
      BallX--;
      BallX--;
       if(BallY > 11) {
        BallY--;
        BallY--;
        BallY--;
      }
      if(BallY < 12) {
        BallDir = 3;
      }
    }
    if(BallDir == 2) {
      BallX++;
      BallX++;
      if(BallY != 11) {
        BallY--;
        BallY--;
        BallY--;
      }
      if(BallY == 11) {
        BallDir = 4;
      }
    }
    if(BallDir == 3) {
     BallX--;
     BallX--;
      if(BallY < 156) {
        BallY++;
        BallY++;
        BallY++;
      }
      if(BallY > 155) {
        BallDir = 1;
      }
    }
    if(BallDir == 4) {
     BallX++;
     BallX++;      
      if(BallY < 150) {
        BallY++;
        BallY++;
        BallY++;
      }
      if(BallY > 149) {
        BallDir = 2;
      }
    }  
    if(BallX > 12) {          /* See if ball is blocked */
     if(BallX < 16) {
      if(Paddle1Y - 8 < BallY) {
        if(Paddle1Y + 24 > BallY) {    
           if(BallDir == 1) {
             BallDir = 2;
           }
           if(BallDir == 3) {
             BallDir = 4;
           }
        }
      }
     } 
    }
    if(BallX > 146) {        /* See if PC blocks ball */
     if(BallX < 151) {
      if(Paddle2Y - 5 < BallY) {
        if(Paddle2Y + 29 > BallY) {    /* Blocked */
           if(BallDir == 2) {
             BallDir = 1;
           }
           if(BallDir == 4) {
             BallDir = 3;
           }
        }
      }
     }
    }
    if(BallX < 5) {      /* if not blocked, give the PC a point */
      comp++;
      BallX = 78;
      BallY = 74;
      gotoxy(3,0);
      printf("I will kick\n   you in the nuts!\n");
      printf("   KENNY : %u  \n", comp);
      printf("              ");
    }
    if(BallX > 165) {      /* if not blocked, give the player a point */
      player++;
      BallX = 78;
      BallY = 74;
      gotoxy(3,0);
      printf("Oh my god!   \n   They scored on  \n   Kenny!   \n");
      printf("   CARTMAN : %u  ", player);
      printf("              ");
    }
    delay(speed);    /* Speed Control here */
  } /* End of while(!0) loop */
}
