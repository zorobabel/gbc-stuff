/* Sample Program to demonstrate the 255 characters GBDK lets you use */
#include <gb.h>

main()
{
  unsigned int a;
  for (a = 0; a != 255; a++)
  {
  printf("%u : %c \n", a);
  delay(250);
  }
}