/* Atari 2600 Classics */
/* Night Driver */
/* Compiled with GBDK 2-0-15 */
/* Again, a 75% true to the 2600, 25% to the gameboy */
/* And hey, all the remarks are commentated */

#include <gb.h>      /* Gameboy routines */
#include <rand.h>    /* random number routines */

fixed seed;

unsigned char NightDrv[] =
{
  0x03,0x00,0x03,0x00,0x33,0x00,0x33,0x00,      /* Car Graphic 1 */
  0x3F,0x00,0x3F,0x00,0x33,0x00,0x33,0x00,
  0xC0,0x00,0xC0,0x00,0xCC,0x00,0xCC,0x00,    /* Car Graphic 2 */
  0xFC,0x00,0xFC,0x00,0xCC,0x00,0xCC,0x00,
  0x00,0x00,0x00,0x00,0x00,0x18,0x00,0x7E,    /* Tree */
  0x00,0xFF,0x00,0xFF,0x18,0x00,0x18,0x00,
  0x00,0x0F,0x00,0x3F,0x00,0xFF,0x00,0xFF,    /* House 1 */
  0x3E,0x00,0x32,0x00,0x33,0x00,0x33,0x00,
  0x00,0x00,0x00,0xC0,0x00,0xF0,0x00,0xF0,    /* House 2 */
  0x40,0x00,0x40,0x00,0xC0,0x00,0xC0,0x00,
  0x00,0xE0,0x40,0xA0,0x40,0xA0,0x00,0xE0,    /* Small Sign */
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0xF0,0x60,0x90,0x60,0x90,0x60,0x90,    /* Medium Sign */
  0x60,0x90,0x00,0xF0,0x00,0x00,0x00,0x00,
  0x00,0xF8,0x70,0x88,0x70,0x88,0x70,0x88,    /* Large Sign */
  0x70,0x88,0x70,0x88,0x70,0x88,0x00,0xF8,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,    /* Blankswitching =) */
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

void night(void);

main()
{
  printf("Atari 2600\n spashscreen\n to go here\n");
  waitpad(J_START + J_A + J_B);
  delay(100);
  seed.b.l = DIV_REG;
  cls();
  printf("Menu to go here");
  waitpad(J_START + J_A + J_B);
  seed.b.h = DIV_REG;
  initarand(seed.w);
  night();
}

void night(void)
{
  unsigned int tempa;    /* temp variable */
  int direction;      /* Way the road leans */
  int shift;        /* Amount the road shifts left/right */
  int timer;    /* Timer between changing directions */
  int treeon;      /* if tree is on */
  int houseon;      /* if house is on */
  unsigned int treehousex;      /*  X-axis for the tree/house */
  unsigned int treehousey;      /* Y-axis for the tree/house */
  unsigned int signya;        /* Y-axis for the sign */
  unsigned int signyb;        /* Y-axis for the sign */
  unsigned int signyc;        /* Y-axis for the sign */
  int signgapa; /* distance between the signs */
  int signgapb; /* distance between the signs */
  int signgapc; /* distance between the signs */
  int playing;    /* If game is playing */
    
  BGP_REG   = 3;     /* Sets background color black */
  cls();      /* Clears the screen */

  direction = 0;      /* set initial values */
  shift = 0;
  timer = 0;
  treeon = 0;
  houseon = 0;
  treehousex = 0;
  treehousey = 0;
  signya = 60;
  signyb = 60;
  signyc = 60;
  playing = 0;
  signgapa = 10;
  signgapb = 20;
  signgapc = 30;
  shift = 80;
      
  SPRITES_8x8;      /* sets sprites to, yep you guessed it, 8x8 mode */
  set_sprite_data(0, 15, NightDrv);   /* defines the sprite data */
  set_sprite_tile(0,0);            /* Car */
  set_sprite_tile(1,1);          /* Car */
  set_sprite_tile(2,2);        /* Tree */
  set_sprite_tile(3,3);        /* House */
  set_sprite_tile(4,4);        /* House */
  set_sprite_tile(5,5);        /* Small Sign */
  set_sprite_tile(6,5);        /* Small Sign */
  set_sprite_tile(7,6);      /* Medium Sign */
  set_sprite_tile(8,6);      /* Medium Sign */
  set_sprite_tile(9,6);      /* Large Sign */
  set_sprite_tile(10,6);      /* Large Sign */
  move_sprite(0, 72, 136);      /* Neat thing about Night Driver is that the car remains stationary =) */
  move_sprite(1, 80, 136);      /* Move car to lower middle */
  SHOW_SPRITES;      /* Wild guess here... shows the sprites? */
  
  while(playing == 0)     /* Game loop */
  {
    if(joypad() & J_START) playing = 1;    /* If start pressed, end gameplay */
    tempa = arand();    /* generate a random number for tempa */
    if((direction == 0) && (tempa < 5)) {    /* all good straightaways must end */
      direction = 1;      /* left turn i think */
    }
    if((direction == 0) && (tempa > 250)) {      /* give the game a challenge */
      direction = 2;      /* right turn i think */
    }
    if(direction == 1) shift = shift - 2;      /* turn the road */
    if(direction == 2) shift = shift + 2;      /* turn the road */
    if(direction > 0) timer++;      /* increase the timer */
    if(timer > 20) {    /* had enough turning? */
      timer = 0;    /* straight away */
      direction = 0;
    }
    if((tempa < shift) && (treeon == 0) && (houseon == 0)) {      /* scenery */
        treehousex = tempa;
        treeon = 1;
    }
    if((tempa > shift) && (treeon == 0) && (houseon == 0)) {    /* scenery */
      treehousex = tempa;
      houseon = 1;
    }
    if(treeon == 1) {      /* move the tree */
      treehousey++;
      treehousey++;
      treehousey++;
      treehousex--;
      move_sprite(2,treehousex, treehousey);
      if(treehousey > 175) {      /* if the tree is off the screen, get rid of it */
        treeon = 0;        
        treehousey = 0;
      }
    }    
    if(houseon == 1) {      /* move the house */
      treehousey++;
      treehousey++;
      treehousey++;
      if(treehousex < 250) treehousex++;    /* keep it from overlapping to the other side */ 
      move_sprite(3,treehousex, treehousey);
      move_sprite(4,treehousex, treehousey);
      if(treehousey > 175) {    /* if the house isn't on the screen, get rid of it */
        houseon = 0;        
        treehousey = 0;
      }
    }    
    if(joypad() & J_LEFT)      /* if left arrow is pressed */
    {
      shift = shift + 3;      /* shift the track to the left */
    }
    if(joypad() & J_RIGHT)      /* if right arrow is pressed */
    {
      shift = shift - 3;      /* shift the track to the right */
    }
    if((shift < shift - signgapa) && (shift < shift - signgapb) && (shift < shift - signgapc)) {   /* if the car goes off the track */
      if(tempa < 100) BGP_REG = 0;      /* screw up the background */
      if((tempa > 100) && (tempa < 200)) BGP_REG = 1;
      if(tempa > 200) BGP_REG = 2;
    }
    if((72 > shift + signgapa) && (72 > shift + signgapb) && (72 > shift + signgapc)) {      /* if the car goes off the track */
      if(tempa < 100) BGP_REG = 0;      /* screw up the background */
      if((tempa > 100) && (tempa < 200)) BGP_REG = 1;
      if(tempa > 200) BGP_REG = 2;
    }
    if((shift > shift - signgapa) && (shift > shift - signgapb) && (shift > shift - signgapc) && (72 < shift + signgapa) && (72 < shift + signgapb) && (72 < shift + signgapc)) {      /* if it's on the track */
      BGP_REG = 3;    /* fix the background */
    }
    signya = signya + 4;        /* increase sign a's y-axis */
    signyb = signyb + 4;       /* increase sign b's y-axis */
    signyc = signyc + 4;       /* increase sign c's y-axis */
    signgapa++;      /* increase sign a's gap */
    signgapb++;       /* increase sign a's gap */
    signgapc++;       /* increase sign a's gap */

    if(signgapa == 50) {      /* if the gap is 50... */
      signgapa = 0;      /* sign gap is 0 */
      signya = 50;      /* sign y-axis is 0 */
    }
    if(signgapb == 50) {      /* if the gap is 50... */
      signgapb = 0;      /* sign gap is 0 */
      signyb = 50;      /* sign y-axis is 0 */
    }
    if(signgapc == 50) {      /* if the gap is 50... */
      signgapc = 0;      /* sign gap is 0 */
      signyc = 50;      /* sign y-axis is 0 */
    }
    if(direction == 0) {    /* straight away keep the sign ahead */
      move_sprite(5,shift - signgapa, signya);      /* Small Sign 1 */
      move_sprite(6,shift + signgapa, signya);     /* Small Sign 2 */
      move_sprite(7,shift - signgapb, signyb);    /* Medium Sign 3 */
      move_sprite(8,shift + signgapb, signyb);    /* Medium Sign 3 */
      move_sprite(9,shift - signgapc, signyc);    /* Medium Sign 3 */
      move_sprite(10,shift + signgapc, signyc);    /* Medium Sign 3 */
    }
    if(direction == 1) {        /* on a turn, move the road */
      move_sprite(5,shift - signgapa + 20, signya);      /* Small Sign 1 */
      move_sprite(6,shift + signgapa + 20, signya);     /* Small Sign 2 */
      move_sprite(7,shift - signgapb + 15, signyb);    /* Medium Sign 3 */
      move_sprite(8,shift + signgapb + 15, signyb);    /* Medium Sign 3 */
      move_sprite(9,shift - signgapc + 10, signyc);    /* Medium Sign 3 */
      move_sprite(10,shift + signgapc + 10, signyc);    /* Medium Sign 3 */
    }
    if(direction == 2) {    /* likewise, on a turn, move the road */
      move_sprite(5,shift - signgapa - 20, signya);      /* Small Sign 1 */
      move_sprite(6,shift + signgapa - 20, signya);     /* Small Sign 2 */
      move_sprite(7,shift - signgapb - 15, signyb);    /* Medium Sign 3 */
      move_sprite(8,shift + signgapb - 15, signyb);    /* Medium Sign 3 */
      move_sprite(9,shift - signgapc - 10, signyc);    /* Medium Sign 3 */
      move_sprite(10,shift + signgapc - 10, signyc);    /* Medium Sign 3 */
    }
    delay(50);      /* wait */
  }  /* End while loop */
  reset();  /* reset game so you can continue */
}  /* End game loop */
/* Thus concludes the game =) */
