/* Atari 2600 for the Gameboy - not an emulator, but a rewrite of classic atari 2600 games */
/* Atari 2600 Boxing */

/* Text screen 20x18 */

#include <gb.h>
#include <rand.h>

fixed seed;

unsigned char Graphics[] =
{
  0x01,0x00,0x7F,0x00,0xFF,0x00,0xFF,0x00,
  0x79,0x00,0x3C,0x00,0x1E,0x00,0x1E,0x00,
  0xF0,0x00,0xF8,0x00,0xFC,0x00,0xFC,0x00,
  0xF8,0x00,0xF0,0x00,0x00,0x00,0x00,0x00,
  0x0F,0x00,0x3F,0x00,0x3F,0x00,0x3F,0x00,
  0x3F,0x00,0x3F,0x00,0x0F,0x00,0x1E,0x00,
  0x00,0x00,0xC0,0x00,0xC0,0x00,0xF0,0x00,
  0xC0,0x00,0xC0,0x00,0x00,0x00,0x00,0x00,
  0x1E,0x00,0x3C,0x00,0x79,0x00,0xF3,0x00,
  0xFF,0x00,0x7F,0x00,0x01,0x00,0x00,0x00,
  0x00,0x00,0xF0,0x00,0xF8,0x00,0xFC,0x00,
  0xFC,0x00,0xF8,0x00,0xF0,0x00,0x00,0x00,
  0x3E,0x3E,0x7F,0x7F,0xFF,0xFF,0xFF,0xFF,
  0x7E,0x7E,0x3C,0x3C,0x01,0x01,0x01,0x01,
  0x00,0x00,0xF8,0xF8,0xFC,0xFC,0x3C,0x3C,
  0x78,0x78,0xF0,0xF0,0xE0,0xE0,0xE0,0xE0,
  0x03,0x03,0x0F,0x0F,0x0F,0x0F,0x3F,0x3F,
  0x0F,0x0F,0x0F,0x0F,0x03,0x03,0x01,0x01,
  0xC0,0xC0,0xF0,0xF0,0xF0,0xF0,0xF0,0xF0,
  0xF0,0xF0,0xF0,0xF0,0xC0,0xC0,0xE0,0xE0,
  0x01,0x01,0x3C,0x3C,0x7E,0x7E,0xFF,0xFF,
  0xFF,0xFF,0x7F,0x7F,0x3E,0x3E,0x00,0x00,
  0xE0,0xE0,0xF0,0xF0,0x78,0x78,0x3C,0x3C,
  0xFC,0xFC,0xF8,0xF8,0x00,0x00,0x00,0x00,
  0x00,0x00,0xFF,0x00,0xFF,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0xFF,0xFF,0xFF,0xFF,0x0,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

void boxing(void);

main()
{
  printf("Atari 2600\n spashscreen\n to go here\n");
  waitpad(J_START + J_A + J_B);
  delay(100);
  seed.b.l = DIV_REG;
  cls();
  printf("Menu to go here");
  waitpad(J_START + J_A + J_B);
  seed.b.h = DIV_REG;
  initarand(seed.w);
  boxing();
}

void boxing(void)          /* Atari 2600 Boxing - rewritten for the gameboy by Jason */
{
  int tempa, ScoreA, ScoreB, playing, key, punchinga, punchingb, punchingc, punchingd;
  unsigned int px, py, cx, cy, tempb;
      
  ScoreA = 0;
  ScoreB = 0;
  
  cls();      /* clears the screen from latter menu */

  printf("\n\n%c", 28);      /* print upper left corner */
  for(tempa = 0; tempa != 18;tempa++) {       /* print top line */
    printf("%c", 14);
  }
  printf("%c", 29);      /* print upper right corner */

  for(tempa = 3; tempa != 16;tempa++) {      /* print side borders */
    printf("%c                  %c", 15, 15);
  }
  printf("%c", 30);          /* print lower left corner */
  for(tempa = 0; tempa != 18;tempa++) {       /* print bottom line */
    printf("%c", 14);
  }
  printf("%c", 31);        /* print lower right corner */  
  
  SPRITES_8x8;      /* sets sprites to, yep you guessed it, 8x8 mode */

  set_sprite_data(0, 13, Graphics);   /* defines the sprite data */
  set_sprite_tile(0,0);            /* defines the tiles numbers */
  set_sprite_tile(1,1);
  set_sprite_tile(2,2);
  set_sprite_tile(3,3);
  set_sprite_tile(4,4);            
  set_sprite_tile(5,5);
  set_sprite_tile(6,6);
  set_sprite_tile(7,7);
  set_sprite_tile(8,8);
  set_sprite_tile(9,9);
  set_sprite_tile(10,10);
  set_sprite_tile(11,11);
  set_sprite_tile(12,12);
  set_sprite_tile(13,13);
  move_sprite(0,16,40);
  move_sprite(1,24,40);
  move_sprite(2,16,48);
  move_sprite(3,24,48);
  move_sprite(4,16,56);
  move_sprite(5,24,56);
  move_sprite(6,146,120);
  move_sprite(7,154,120);
  move_sprite(8,146,128);
  move_sprite(9,154,128);
  move_sprite(10,146,136);
  move_sprite(11,154,136);
  SHOW_SPRITES;
  
  px = 16;
  py = 40;
  cx = 146;
  cy = 120;
  playing = 1;
  punchinga = 0;
  punchingb = 0;
  punchingc = 0;
  punchingd = 0;
    
  while(playing == 1) {      /* game playing loop */
    if((ScoreA == 50) || (ScoreB == 50)) playing--;
    gotoxy(7,0);            /* Game name and scoreboard */
    printf("BOXING\n");
    printf("P1 : %d", ScoreA);
    gotoxy(11,1);
    printf("P2 : %d", ScoreB);
    tempb = arand();
   if(py + 8 == cy) {      /* If computer gets a hit, deck the boxer */
      if(px + 20 == cx) {
        if(tempb < 25) {
          punchingc = 1;
          ScoreB++;
          if(px > 24) px = px - 15;          
          delay(5);
        }
      }
    }
    if(py + 8 < cy) {
      if(tempb < 150) {
        cy--;
      }
    }
    if(py + 8 > cy) {
      if(tempb < 150) {
        cy++;
      }
    }
    if(px + 20 < cx) {
      if(tempb < 150) {
        cx--;
        if((punchinga == 1) || (punchingb == 1)) {
          if(tempb > 5) cx++;
        }
      }
    }
    if(px + 20 > cx) {
     if(cx < 146) {
      if(tempb < 150) {
        cx++;
      }
     }
    }
    key = joypad();
    if(key & J_A) {
      punchinga = 1;
    }
    if(key & J_B) {
      punchingb = 1;
    }
    if(key & J_DOWN) {
      if(py < 120) {
        py++;
      }    
    }
    if(key & J_UP) {
      if(py > 40) {
        py--;
      }    
    }
    if(key & J_LEFT) {
      if(px > 16) {
        px--;
      }    
    }
    if(key & J_RIGHT) {
      if(px < 146) {
        px++;
      }    
    }
    if(punchinga == 1) {      /* does you smell what the player's cookin? */
      if((py < cy) && (py + 8 > cy)) {
        if((px + 16 < cx) && (px + 24 > cx)) {
          ScoreA++;
          if(cx < 140) cx = cx + 15;
        }
      }
    }
    if(punchingb == 1) {      /* If player decks pc, lay the smack down on it */
      if(py + 8 == cy) {
        if(px + 20 == cx) {
          if(tempb < 30) {
            ScoreA++;
            if(cx < 140) cx = cx + 15;
          }
        }
      }
    }
    
    move_sprite(0,px,py);
    if(punchinga == 0) move_sprite(1,px + 8,py);
    if(punchinga == 1) {
      move_sprite(1,px + 16,py);
      move_sprite(12, px + 8, py);
      punchingb = 0;
    }
    move_sprite(2,px,py+8);
    move_sprite(3,px + 8,py+8);
    move_sprite(4,px,py+16);
    if(punchingb == 0) move_sprite(5,px + 8,py+16);
    if(punchingb == 1) {
      move_sprite(5,px + 16,py+16);
      move_sprite(12, px + 8, py+18);
      punchinga = 0;
    }
    if(punchingc == 0) move_sprite(6,cx,cy);
    if(punchingc == 1) {
      move_sprite(6,cx - 8,cy);
      move_sprite(12, cx, cy);
      punchingc = 0;
    }
    move_sprite(7,cx+8,cy);
    move_sprite(8,cx,cy+8);
    move_sprite(9,cx+8,cy+8);
    if(punchingd == 0) move_sprite(10,cx,cy+16);
    move_sprite(11,cx+8,cy+16);
    delay(5);      /* Master speed control */
    tempa++;
    key = 0;
    if(tempa == 2) {
      punchinga = 0;
      punchingb = 0;
      punchingc = 0;
      punchingd = 0;
      move_sprite(12, 255,255);
    }
  }    /* End while loop */
  if(ScoreA == 50) {
    while(cx < 200) {
      cx++;
      move_sprite(6,cx,cy);
      move_sprite(7,cx+8,cy);
      move_sprite(8,cx,cy+8);
      move_sprite(9,cx+8,cy+8);
      move_sprite(10,cx,cy+16);
      move_sprite(11,cx+8,cy+16);
      delay(10);
    }
  }
  if(ScoreB == 50) {
    while(px >  0) {
      px--;
      move_sprite(1,px,py);
      move_sprite(2,px+8,py);
      move_sprite(3,px,py+8);
      move_sprite(4,px+8,py+8);
      move_sprite(5,px,py+16);
      move_sprite(6,px+8,py+16);
      delay(10);
    }
  }
  cls();
  move_sprite(0,255,255);
  move_sprite(1,255,255);
  move_sprite(2,255,255);
  move_sprite(3,255,255);
  move_sprite(4,255,255);
  move_sprite(5,255,255);
  move_sprite(6,255,255);
  move_sprite(7,255,255);
  move_sprite(8,255,255);
  move_sprite(9,255,255);
  move_sprite(10,255,255);
  move_sprite(11,255,255);
  move_sprite(12,255,255);
  move_sprite(13,255,255);
  cls();
  gotoxy(0,3);
  printf("         KO\n\n");
  printf(" Player 1 : %d \n", ScoreA);
  printf(" Computer : %d \n\n", ScoreB);
  if(ScoreA == 50) printf(" You win.");
  if(ScoreB == 50) printf(" Computer wins.");
  waitpad(J_A + J_B + J_START);
  reset();
}
