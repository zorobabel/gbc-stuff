// Fade.C
// Written By Jason
//
// I don't mind if you leech my code and use it in non-commercial or commercial 
// projects, just give me credit, and don't go claiming you wrote the routine
// like certain people have in the past. There's alot of lamers out there in
// #gbdev-land
// The only thing you need to do is...
//   The fadevalue 1057 is 000010000100001 binary. This is the fade value for a 
//   grayscale image. As a result, color images won't fade. They will, but you
//   have to write a routine to check the value of each r, g, b value and make
//   sure they don't decrease below 0. Pretty easy to do, but I'm a lazy man 
//   when it comes to coding shit.

#include <gb.h>					// Gameboy Defines
#include <colors.h>				// Color Defines
#include "fox.dat"
#include "fox.map"

#define fadevalue 1057				// fade value constant

void fade(void);				// fades the image

UWORD palette[64];				// palette information
UWORD testpal[] = {				// test palette
black,darkgray,lightgray,white,
};

main()
{
	unsigned int x;				// da

	x=0;					// da

	palette[0] = black;
	palette[1] = darkgray;
	palette[2] = lightgray;
	palette[3] = white;

	set_bkg_data(0,35,foxtiledata);		// show fox logo
	set_bkg_tiles(6,6,7,5,foxtilemap);	// show fox logo
	set_bkg_palette(0,2,&palette[0]);	// show fox logo
	SHOW_BKG;				// show fox logo
	DISPLAY_ON;				// show fox logo

	fade();

	reset();
	return(0);
}

void fade(void)
{
	unsigned int y;

	y = 0;

	while(y == 0) {
	 if(palette[0] == 0) {
		if(palette[1] == 0) {
			if(palette[2] == 0) {
				if(palette[3] == 0) {
					y++;
				}
			}
		}
	 }
 	 if(palette[0] != 0) palette[0] = palette[0] - fadevalue;
	 if(palette[1] != 0) palette[1] = palette[1] - fadevalue;
	 if(palette[2] != 0) palette[2] = palette[2] - fadevalue;
	 if(palette[3] != 0) palette[3] = palette[3] - fadevalue;
	 set_bkg_palette(0,2,&palette[0]);	// show fox logo
	 delay(50);	
	}
}
