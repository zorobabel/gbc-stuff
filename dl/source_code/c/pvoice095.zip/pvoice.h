/* This is a pre-release version of my (Ed Mandy) PVoice library.
   Since I don't feel that it's complete, yet, I will only release it
   as a .o (object) file.  Call it version 0.95, I suppose.

   I used GBDK v 2.1.5 to compile the file.

   Oh, and all I ask is that you give me credit if you use this in any
   of your creations.  If you do use it, I'd like to hear about it, but
   in any case, please just give me credit in your program.

   Thanks,
   Ed Mandy
   emandy@atcorp.com
   ICQ:  17868116
*/

/*  Call this before recording/playing.
    */
void initPVoice();


/*  playVoice will play numBytes of data from the buffer that sound points
    to.
*/
UWORD playVoice(const void *sound, UWORD numBytes);

/*  recVoice will record numBytes of data to the buffer that sound points
    to.
    If you release the A button, recVoice will stop recording.
    I would recommend asking the user to press-and-hold the A button
    until they are done recording.  Call recVoice once they have pressed
    the A button, and recVoice will return either when the A button has
    been released or when numBytes have been recorded (whichever comes
    first).
*/
UWORD recVoice(const void *sound, UWORD numBytes);

