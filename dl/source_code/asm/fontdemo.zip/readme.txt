The FontDemo program displays the use of the string code that I wrote. It takes a normal ASCII string (terminated by a null) and creates the tile data necessary to display the string on the GB screen.

There are a lot of comments in the source code (A lot for me anyway) so I'll let you jump in and get your hands dirty.

